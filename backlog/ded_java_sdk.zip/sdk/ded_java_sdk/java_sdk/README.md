# DED Java SDK

Java SDK for the Digital Evidence (DED) Metagraph. Generate and submit cryptographically signed fingerprints.

## Features

- Generate cryptographically signed fingerprints
- SECP256K1 ECDSA signatures using Bouncy Castle
- RFC 8785 JSON Canonicalization
- Batch fingerprint generation
- API submission support
- Flexible configuration via environment variables, config file, or CLI
- Interactive command-line interface

## Requirements

- Java 11 or higher
- Maven 3.6 or higher (for building)

## Installation

```bash
./setup
```

The setup script will:
1. Check for Java and Maven installation
2. Optionally install missing dependencies
3. Build the project with Maven
4. Create an executable JAR file

## Configuration

The SDK supports multiple configuration methods with the following priority order:
1. **Command Line Arguments** (highest priority for CLI usage)
2. **Environment Variables** (recommended for production)
3. **Configuration File** (`config/config.json`)
4. **Default Values** (lowest priority)

### Environment Variables

```bash
export DED_API_KEY="your_api_key_here"
export DED_ORG_ID="your-organization-id"
export DED_TENANT_ID="your-tenant-id"
export DED_API_ENDPOINT="https://de-api.constellationnetwork.io/v1/fingerprints"
export DED_OUTPUT_DIR="./output"
export DED_PRIVATE_KEY="your_private_key_hex"  # Optional
```

### Configuration File

Edit `config/config.json`:
```json
{
  "apiKey": "your_api_key_here",
  "apiEndpoint": "https://de-api.constellationnetwork.io/v1/fingerprints",
  "orgId": "your-org-id",
  "tenantId": "your-tenant-id",
  "outputDir": "./output"
}
```

### View Current Configuration

```bash
java -jar target/ded-java-sdk-1.0.0.jar config
```

## Usage

### Interactive Mode

```bash
./run
```

The interactive runner provides a menu-driven interface for:
1. Generating fingerprints
2. Submitting to API
3. Running full flow (generate + submit)
4. Viewing configuration
5. Configuring the SDK

### Command Line Interface

```bash
# Generate fingerprints (default: 5)
java -jar target/ded-java-sdk-1.0.0.jar generate

# Generate custom count
java -jar target/ded-java-sdk-1.0.0.jar generate --count 10

# Generate with specific org and tenant
java -jar target/ded-java-sdk-1.0.0.jar generate --org-id "my-org" --tenant-id "my-tenant"

# Generate with custom private key
java -jar target/ded-java-sdk-1.0.0.jar generate --private-key "your_hex_key"

# Generate without metadata
java -jar target/ded-java-sdk-1.0.0.jar generate --no-metadata

# Verbose output
java -jar target/ded-java-sdk-1.0.0.jar generate -v
```

### Submit to API

```bash
# Submit generated fingerprints
java -jar target/ded-java-sdk-1.0.0.jar submit

# Submit with custom API key
java -jar target/ded-java-sdk-1.0.0.jar submit -k YOUR_API_KEY

# Submit with custom endpoint
java -jar target/ded-java-sdk-1.0.0.jar submit -e "https://your-api.com/fingerprints"
```

### Generate and Submit

```bash
# Generate and submit in one command
java -jar target/ded-java-sdk-1.0.0.jar all

# With custom count
java -jar target/ded-java-sdk-1.0.0.jar all --count 10
```

## Programmatic Usage

```java
import com.constellationnetwork.ded.sdk.FingerprintGenerator;
import com.constellationnetwork.ded.sdk.ConfigManager;
import com.constellationnetwork.ded.sdk.SDKConfig;

// Method 1: Use default/environment configuration
FingerprintGenerator generator = new FingerprintGenerator();

// Method 2: Override specific configuration
SDKConfig config = new SDKConfig();
config.setOrgId("my-org-id");
config.setTenantId("my-tenant-id");
config.setPrivateKey("your-private-key-hex");
FingerprintGenerator generator = new FingerprintGenerator(config);

// Method 3: Use ConfigManager for global configuration
ConfigManager configManager = ConfigManager.getInstance();
SDKConfig updates = new SDKConfig();
updates.setApiKey("your-api-key");
updates.setOrgId("your-org-id");
updates.setTenantId("your-tenant-id");
configManager.updateConfig(updates);

// Generate fingerprints
List<FingerprintGenerator.FingerprintSubmission> submissions =
    generator.generateBatch(5, true);

// Get configuration info
FingerprintGenerator.KeyInfo keyInfo = generator.getKeyInfo();
System.out.println("Using org: " + keyInfo.orgId);
System.out.println("Using tenant: " + keyInfo.tenantId);
System.out.println("Public key: " + keyInfo.publicKey);

// Factory method
FingerprintGenerator customGenerator = FingerprintGenerator.withConfig(config);
```

## Output

Generated fingerprints are saved to `output/fingerprint_submissions.json`

## Signing Protocol

1. RFC 8785 JSON Canonicalization
2. UTF-8 encoding
3. SHA-256 hash
4. Convert to hex string
5. Treat hex as UTF-8 text
6. SHA-512 hash
7. Truncate to 32 bytes
8. ECDSA sign with SECP256K1

## Development

```bash
# Build the project
mvn clean package

# Run tests (if available)
mvn test

# Clean build artifacts
mvn clean
```

## Dependencies

- **Bouncy Castle** (bcprov-jdk18on, bcpkix-jdk18on) - Cryptographic operations
- **java-json-canonicalization** - RFC 8785 JSON canonicalization
- **Gson** - JSON processing
- **PicoCLI** - Command-line interface
- **Apache HttpClient** - HTTP client for API submission
- **SLF4J** - Logging

## Security Notes

- **Never commit API keys or private keys to version control**
- Use environment variables for sensitive configuration in production
- The SDK will generate a new private key if one is not provided
- Private keys should be stored securely and backed up
- API keys should have minimal required permissions

## Project Structure

```
java_sdk/
├── config/
│   └── config.json          # Configuration file
├── output/                  # Generated fingerprints output
├── src/main/java/com/constellationnetwork/ded/sdk/
│   ├── CLI.java            # Command-line interface
│   ├── ConfigManager.java  # Configuration management
│   ├── FingerprintGenerator.java  # Core fingerprint generation
│   └── SDKConfig.java      # Configuration data class
├── pom.xml                 # Maven configuration
├── setup                   # Setup script
├── run                     # Interactive runner script
└── README.md              # This file
```

## License

MIT