package com.constellationnetwork.ded.sdk;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.erdtman.jcs.JsonCanonicalizer;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.signers.ECDSASigner;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.Security;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class FingerprintGenerator {
    private final String orgId;
    private final String tenantId;
    private final byte[] privateKey;
    private final String publicKeyHex;
    private final SDKConfig config;
    private final Gson gson;
    private final ECDomainParameters ecDomainParameters;

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    public FingerprintGenerator() {
        this(null);
    }

    public FingerprintGenerator(SDKConfig configUpdates) {
        ConfigManager configManager = ConfigManager.getInstance();
        if (configUpdates != null) {
            configManager.updateConfig(configUpdates);
        }
        this.config = configManager.getConfig();

        this.orgId = this.config.getOrgId();
        this.tenantId = this.config.getTenantId();

        X9ECParameters params = SECNamedCurves.getByName("secp256k1");
        this.ecDomainParameters = new ECDomainParameters(
            params.getCurve(),
            params.getG(),
            params.getN(),
            params.getH()
        );

        if (this.config.getPrivateKey() != null && !this.config.getPrivateKey().isEmpty()) {
            this.privateKey = Hex.decode(this.config.getPrivateKey());
        } else {
            this.privateKey = generatePrivateKey();
        }

        this.publicKeyHex = derivePublicKey(this.privateKey);
        this.gson = new GsonBuilder().disableHtmlEscaping().create();
    }

    private byte[] generatePrivateKey() {
        SecureRandom random = new SecureRandom();
        byte[] key = new byte[32];
        random.nextBytes(key);
        return key;
    }

    private String derivePublicKey(byte[] privateKey) {
        BigInteger privateKeyInt = new BigInteger(1, privateKey);
        org.bouncycastle.math.ec.ECPoint publicPoint = ecDomainParameters.getG().multiply(privateKeyInt);
        byte[] publicKeyBytes = publicPoint.getEncoded(false);

        if (publicKeyBytes[0] == 0x04 && publicKeyBytes.length == 65) {
            byte[] rawPublicKey = new byte[64];
            System.arraycopy(publicKeyBytes, 1, rawPublicKey, 0, 64);
            return Hex.toHexString(rawPublicKey);
        }

        return Hex.toHexString(publicKeyBytes);
    }

    private String canonicalizeJson(Object data) throws Exception {
        String json = gson.toJson(data);
        JsonCanonicalizer canonicalizer = new JsonCanonicalizer(json);
        return canonicalizer.getEncodedString();
    }

    private SignedFingerprint signFingerprint(FingerprintValue fingerprintValue) throws Exception {
        String canonicalJson = canonicalizeJson(fingerprintValue);

        byte[] utf8Bytes = canonicalJson.getBytes(StandardCharsets.UTF_8);

        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = sha256.digest(utf8Bytes);

        String hashHex = Hex.toHexString(hashBytes);
        byte[] hashBytesForSigning = hashHex.getBytes(StandardCharsets.UTF_8);

        MessageDigest sha512 = MessageDigest.getInstance("SHA-512");
        byte[] sha512Hash = sha512.digest(hashBytesForSigning);
        byte[] truncatedHash = Arrays.copyOfRange(sha512Hash, 0, 32);

        BigInteger privateKeyInt = new BigInteger(1, privateKey);
        ECPrivateKeyParameters privKeyParams = new ECPrivateKeyParameters(privateKeyInt, ecDomainParameters);

        ECDSASigner signer = new ECDSASigner();
        signer.init(true, privKeyParams);

        BigInteger[] signature = signer.generateSignature(truncatedHash);
        byte[] derSignature = encodeToDER(signature[0], signature[1]);

        SignatureProof proof = new SignatureProof();
        proof.id = this.publicKeyHex;
        proof.signature = Hex.toHexString(derSignature);
        proof.algorithm = "SECP256K1_RFC8785_V1";

        SignedFingerprint signed = new SignedFingerprint();
        signed.content = fingerprintValue;
        signed.proofs = Collections.singletonList(proof);

        return signed;
    }

    private byte[] encodeToDER(BigInteger r, BigInteger s) {
        byte[] rBytes = r.toByteArray();
        byte[] sBytes = s.toByteArray();

        int rLen = rBytes.length;
        int sLen = sBytes.length;
        int totalLen = 2 + rLen + 2 + sLen;

        byte[] der = new byte[2 + totalLen];
        int offset = 0;

        der[offset++] = 0x30;
        der[offset++] = (byte) totalLen;

        der[offset++] = 0x02;
        der[offset++] = (byte) rLen;
        System.arraycopy(rBytes, 0, der, offset, rLen);
        offset += rLen;

        der[offset++] = 0x02;
        der[offset++] = (byte) sLen;
        System.arraycopy(sBytes, 0, der, offset, sLen);

        return der;
    }

    private FingerprintValue generateFingerprintValue(int index, String documentPrefix) throws Exception {
        String eventId = UUID.randomUUID().toString();
        String documentId = String.format("%s-%03d", documentPrefix, index + 1);

        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] docHash = sha256.digest(documentId.getBytes(StandardCharsets.UTF_8));
        String documentRef = Hex.toHexString(docHash);

        Instant now = Instant.now();
        Instant timestamp = now.minus(5, ChronoUnit.MINUTES).minus(index * 60L, ChronoUnit.SECONDS);
        String timestampStr = timestamp.toString();

        FingerprintValue value = new FingerprintValue();
        value.orgId = this.orgId;
        value.tenantId = this.tenantId;
        value.eventId = eventId;
        value.documentId = documentId;
        value.documentRef = documentRef;
        value.timestamp = timestampStr;
        value.version = 1;
        value.signerId = this.publicKeyHex;

        return value;
    }

    public FingerprintSubmission generateSubmission(int index, boolean includeMetadata) throws Exception {
        FingerprintValue fingerprintValue = generateFingerprintValue(index, "doc");
        SignedFingerprint signedFingerprint = signFingerprint(fingerprintValue);

        FingerprintSubmission submission = new FingerprintSubmission();
        submission.attestation = signedFingerprint;

        if (includeMetadata) {
            String canonicalJson = canonicalizeJson(fingerprintValue);
            MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = sha256.digest(canonicalJson.getBytes(StandardCharsets.UTF_8));
            String hashHex = Hex.toHexString(hashBytes);

            FingerprintMetadata metadata = new FingerprintMetadata();
            metadata.hash = hashHex;
            metadata.tags = new HashMap<>();

            if (index % 2 == 0) {
                metadata.tags.put("index", String.valueOf(index));
                metadata.tags.put("category", "batch-1");
                if (index % 3 == 0) {
                    metadata.tags.put("priority", "high");
                }
            }
            metadata.tags.put("generator", "Java-SDK");

            submission.metadata = metadata;
        }

        return submission;
    }

    public List<FingerprintSubmission> generateBatch(int count, boolean includeMetadata) throws Exception {
        List<FingerprintSubmission> submissions = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            submissions.add(generateSubmission(i, includeMetadata));
        }
        return submissions;
    }

    public KeyInfo getKeyInfo() {
        return new KeyInfo(this.publicKeyHex, this.publicKeyHex.length(), this.orgId, this.tenantId);
    }

    public SDKConfig getConfig() {
        return this.config.copy();
    }

    public static FingerprintGenerator withConfig(SDKConfig config) {
        return new FingerprintGenerator(config);
    }

    public static class FingerprintValue {
        public String orgId;
        public String tenantId;
        public String eventId;
        public String documentId;
        public String documentRef;
        public String timestamp;
        public int version;
        public String signerId;
    }

    public static class SignatureProof {
        public String id;
        public String signature;
        public String algorithm;
    }

    public static class SignedFingerprint {
        public FingerprintValue content;
        public List<SignatureProof> proofs;
    }

    public static class FingerprintMetadata {
        public String hash;
        public Map<String, String> tags;
    }

    public static class FingerprintSubmission {
        public SignedFingerprint attestation;
        public FingerprintMetadata metadata;
    }

    public static class KeyInfo {
        public final String publicKey;
        public final int publicKeyLength;
        public final String orgId;
        public final String tenantId;

        public KeyInfo(String publicKey, int publicKeyLength, String orgId, String tenantId) {
            this.publicKey = publicKey;
            this.publicKeyLength = publicKeyLength;
            this.orgId = orgId;
            this.tenantId = tenantId;
        }
    }
}