package com.constellationnetwork.ded.sdk;

public class SDKConfig {
    private String apiKey;
    private String apiEndpoint;
    private String orgId;
    private String tenantId;
    private String outputDir;
    private String privateKey;

    public SDKConfig() {
        this.apiKey = "YOUR_API_KEY_HERE";
        this.apiEndpoint = "https://de-api.constellationnetwork.io/v1/fingerprints";
        this.orgId = "11111111-1111-1111-1111-111111111111";
        this.tenantId = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";
        this.outputDir = "./output";
        this.privateKey = null;
    }

    public SDKConfig(String apiKey, String apiEndpoint, String orgId, String tenantId, String outputDir, String privateKey) {
        this.apiKey = apiKey;
        this.apiEndpoint = apiEndpoint;
        this.orgId = orgId;
        this.tenantId = tenantId;
        this.outputDir = outputDir;
        this.privateKey = privateKey;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getApiEndpoint() {
        return apiEndpoint;
    }

    public void setApiEndpoint(String apiEndpoint) {
        this.apiEndpoint = apiEndpoint;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getOutputDir() {
        return outputDir;
    }

    public void setOutputDir(String outputDir) {
        this.outputDir = outputDir;
    }

    public String getPrivateKey() {
        return privateKey;
    }

    public void setPrivateKey(String privateKey) {
        this.privateKey = privateKey;
    }

    public SDKConfig copy() {
        return new SDKConfig(apiKey, apiEndpoint, orgId, tenantId, outputDir, privateKey);
    }
}