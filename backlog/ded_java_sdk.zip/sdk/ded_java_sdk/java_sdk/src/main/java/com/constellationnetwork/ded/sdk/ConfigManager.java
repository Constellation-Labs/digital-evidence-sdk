package com.constellationnetwork.ded.sdk;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ConfigManager {
    private static ConfigManager instance;
    private SDKConfig config;
    private final Gson gson;

    private ConfigManager() {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.config = loadConfiguration();
    }

    public static synchronized ConfigManager getInstance() {
        if (instance == null) {
            instance = new ConfigManager();
        }
        return instance;
    }

    private SDKConfig loadConfiguration() {
        SDKConfig defaultConfig = new SDKConfig();

        SDKConfig fileConfig = loadFromFile();
        SDKConfig envConfig = loadFromEnvironment();

        if (fileConfig.getApiKey() != null && !fileConfig.getApiKey().equals("YOUR_API_KEY_HERE")) {
            defaultConfig.setApiKey(fileConfig.getApiKey());
        }
        if (fileConfig.getApiEndpoint() != null) {
            defaultConfig.setApiEndpoint(fileConfig.getApiEndpoint());
        }
        if (fileConfig.getOrgId() != null) {
            defaultConfig.setOrgId(fileConfig.getOrgId());
        }
        if (fileConfig.getTenantId() != null) {
            defaultConfig.setTenantId(fileConfig.getTenantId());
        }
        if (fileConfig.getOutputDir() != null) {
            defaultConfig.setOutputDir(fileConfig.getOutputDir());
        }
        if (fileConfig.getPrivateKey() != null) {
            defaultConfig.setPrivateKey(fileConfig.getPrivateKey());
        }

        if (envConfig.getApiKey() != null && !envConfig.getApiKey().equals("YOUR_API_KEY_HERE")) {
            defaultConfig.setApiKey(envConfig.getApiKey());
        }
        if (envConfig.getApiEndpoint() != null) {
            defaultConfig.setApiEndpoint(envConfig.getApiEndpoint());
        }
        if (envConfig.getOrgId() != null) {
            defaultConfig.setOrgId(envConfig.getOrgId());
        }
        if (envConfig.getTenantId() != null) {
            defaultConfig.setTenantId(envConfig.getTenantId());
        }
        if (envConfig.getOutputDir() != null) {
            defaultConfig.setOutputDir(envConfig.getOutputDir());
        }
        if (envConfig.getPrivateKey() != null) {
            defaultConfig.setPrivateKey(envConfig.getPrivateKey());
        }

        ensureOutputDirectory(defaultConfig.getOutputDir());

        return defaultConfig;
    }

    private SDKConfig loadFromFile() {
        SDKConfig config = new SDKConfig();

        String[] possiblePaths = {
            "config/config.json",
            "./config/config.json",
            System.getProperty("user.dir") + "/config/config.json"
        };

        for (String path : possiblePaths) {
            File configFile = new File(path);
            if (configFile.exists()) {
                try (FileReader reader = new FileReader(configFile)) {
                    SDKConfig loadedConfig = gson.fromJson(reader, SDKConfig.class);
                    if (loadedConfig != null && loadedConfig.getApiKey() != null) {
                        return loadedConfig;
                    }
                } catch (IOException e) {
                    System.err.println("Warning: Failed to parse config.json at " + path + ": " + e.getMessage());
                }
                break;
            }
        }

        return config;
    }

    private SDKConfig loadFromEnvironment() {
        SDKConfig config = new SDKConfig();

        String apiKey = System.getenv("DED_API_KEY");
        if (apiKey != null) {
            config.setApiKey(apiKey);
        }

        String apiEndpoint = System.getenv("DED_API_ENDPOINT");
        if (apiEndpoint != null) {
            config.setApiEndpoint(apiEndpoint);
        }

        String orgId = System.getenv("DED_ORG_ID");
        if (orgId != null) {
            config.setOrgId(orgId);
        }

        String tenantId = System.getenv("DED_TENANT_ID");
        if (tenantId != null) {
            config.setTenantId(tenantId);
        }

        String outputDir = System.getenv("DED_OUTPUT_DIR");
        if (outputDir != null) {
            config.setOutputDir(outputDir);
        }

        String privateKey = System.getenv("DED_PRIVATE_KEY");
        if (privateKey != null) {
            config.setPrivateKey(privateKey);
        }

        return config;
    }

    private void ensureOutputDirectory(String outputDir) {
        try {
            Path path = Paths.get(outputDir);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            System.err.println("Warning: Failed to create output directory: " + e.getMessage());
        }
    }

    public SDKConfig getConfig() {
        return config.copy();
    }

    public void updateConfig(SDKConfig updates) {
        if (updates.getApiKey() != null) {
            this.config.setApiKey(updates.getApiKey());
        }
        if (updates.getApiEndpoint() != null) {
            this.config.setApiEndpoint(updates.getApiEndpoint());
        }
        if (updates.getOrgId() != null) {
            this.config.setOrgId(updates.getOrgId());
        }
        if (updates.getTenantId() != null) {
            this.config.setTenantId(updates.getTenantId());
        }
        if (updates.getOutputDir() != null) {
            this.config.setOutputDir(updates.getOutputDir());
        }
        if (updates.getPrivateKey() != null) {
            this.config.setPrivateKey(updates.getPrivateKey());
        }
    }

    public ValidationResult validateConfig() {
        List<String> errors = new ArrayList<>();

        if (config.getApiKey().equals("YOUR_API_KEY_HERE")) {
            errors.add("API key not configured. Set DED_API_KEY environment variable or update config.json");
        }

        if (config.getOrgId() == null || config.getOrgId().equals("11111111-1111-1111-1111-111111111111")) {
            errors.add("Using default org ID. Consider setting DED_ORG_ID environment variable or update config.json");
        }

        if (config.getTenantId() == null || config.getTenantId().equals("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")) {
            errors.add("Using default tenant ID. Consider setting DED_TENANT_ID environment variable or update config.json");
        }

        return new ValidationResult(errors.isEmpty(), errors);
    }

    public String getConfigInfo() {
        ValidationResult validation = validateConfig();
        StringBuilder info = new StringBuilder();

        info.append("Configuration:\n");
        info.append("  • API Endpoint: ").append(config.getApiEndpoint()).append("\n");

        String apiKeyDisplay = config.getApiKey().equals("YOUR_API_KEY_HERE")
            ? "NOT SET"
            : config.getApiKey().substring(0, Math.min(10, config.getApiKey().length())) + "...";
        info.append("  • API Key: ").append(apiKeyDisplay).append("\n");
        info.append("  • Organization ID: ").append(config.getOrgId()).append("\n");
        info.append("  • Tenant ID: ").append(config.getTenantId()).append("\n");
        info.append("  • Output Directory: ").append(config.getOutputDir()).append("\n");

        if (!validation.isValid()) {
            info.append("\nWarnings:\n");
            for (String error : validation.getErrors()) {
                info.append("  ⚠️  ").append(error).append("\n");
            }
        }

        return info.toString();
    }

    public static class ValidationResult {
        private final boolean valid;
        private final List<String> errors;

        public ValidationResult(boolean valid, List<String> errors) {
            this.valid = valid;
            this.errors = errors;
        }

        public boolean isValid() {
            return valid;
        }

        public List<String> getErrors() {
            return errors;
        }
    }
}