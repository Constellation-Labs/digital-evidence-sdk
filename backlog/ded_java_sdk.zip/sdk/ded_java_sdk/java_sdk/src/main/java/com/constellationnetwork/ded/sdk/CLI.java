package com.constellationnetwork.ded.sdk;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Callable;

@Command(name = "ded-fingerprint", mixinStandardHelpOptions = true, version = "1.0.0",
        description = "DED Java SDK - Generate and submit cryptographically signed fingerprints",
        subcommands = {CLI.ConfigCommand.class, CLI.GenerateCommand.class, CLI.SubmitCommand.class, CLI.AllCommand.class})
public class CLI implements Callable<Integer> {

    public static void main(String[] args) {
        int exitCode = new CommandLine(new CLI()).execute(args);
        System.exit(exitCode);
    }

    @Override
    public Integer call() {
        System.out.println("DED Java SDK");
        System.out.println("Use --help to see available commands");
        return 0;
    }

    @Command(name = "config", description = "Display current configuration")
    static class ConfigCommand implements Callable<Integer> {
        @Override
        public Integer call() {
            ConfigManager configManager = ConfigManager.getInstance();
            System.out.println(configManager.getConfigInfo());
            return 0;
        }
    }

    @Command(name = "generate", description = "Generate fingerprints")
    static class GenerateCommand implements Callable<Integer> {
        @Option(names = {"-c", "--count"}, description = "Number of fingerprints to generate", defaultValue = "5")
        private int count;

        @Option(names = {"--no-metadata"}, description = "Generate without metadata")
        private boolean noMetadata;

        @Option(names = {"--org-id"}, description = "Override organization ID")
        private String orgId;

        @Option(names = {"--tenant-id"}, description = "Override tenant ID")
        private String tenantId;

        @Option(names = {"--private-key"}, description = "Use specific private key (hex)")
        private String privateKey;

        @Option(names = {"-v", "--verbose"}, description = "Verbose output")
        private boolean verbose;

        @Override
        public Integer call() {
            try {
                SDKConfig configUpdates = new SDKConfig();
                if (orgId != null) {
                    configUpdates.setOrgId(orgId);
                }
                if (tenantId != null) {
                    configUpdates.setTenantId(tenantId);
                }
                if (privateKey != null) {
                    configUpdates.setPrivateKey(privateKey);
                }

                FingerprintGenerator generator = new FingerprintGenerator(configUpdates);

                if (verbose) {
                    FingerprintGenerator.KeyInfo keyInfo = generator.getKeyInfo();
                    System.out.println("Configuration:");
                    System.out.println("  Org ID: " + keyInfo.orgId);
                    System.out.println("  Tenant ID: " + keyInfo.tenantId);
                    System.out.println("  Public Key: " + keyInfo.publicKey);
                    System.out.println();
                }

                System.out.println("Generating " + count + " fingerprints...");
                List<FingerprintGenerator.FingerprintSubmission> submissions = generator.generateBatch(count, !noMetadata);

                Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
                String json = gson.toJson(submissions);

                String outputDir = generator.getConfig().getOutputDir();
                Path outputPath = Paths.get(outputDir, "fingerprint_submissions.json");
                Files.createDirectories(outputPath.getParent());
                Files.writeString(outputPath, json);

                System.out.println("✅ Generated " + submissions.size() + " fingerprints");
                System.out.println("   Saved to: " + outputPath.toAbsolutePath());

                if (verbose) {
                    System.out.println("\nFirst fingerprint:");
                    System.out.println(gson.toJson(submissions.get(0)));
                }

                return 0;
            } catch (Exception e) {
                System.err.println("Error generating fingerprints: " + e.getMessage());
                e.printStackTrace();
                return 1;
            }
        }
    }

    @Command(name = "submit", description = "Submit fingerprints to API")
    static class SubmitCommand implements Callable<Integer> {
        @Option(names = {"-k", "--api-key"}, description = "Override API key")
        private String apiKey;

        @Option(names = {"-e", "--endpoint"}, description = "Override API endpoint")
        private String endpoint;

        @Option(names = {"-i", "--input"}, description = "Input file", defaultValue = "fingerprint_submissions.json")
        private String inputFile;

        @Option(names = {"--org-id"}, description = "Override organization ID")
        private String orgId;

        @Option(names = {"--tenant-id"}, description = "Override tenant ID")
        private String tenantId;

        @Override
        public Integer call() {
            try {
                ConfigManager configManager = ConfigManager.getInstance();
                SDKConfig config = configManager.getConfig();

                if (apiKey != null) {
                    config.setApiKey(apiKey);
                }
                if (endpoint != null) {
                    config.setApiEndpoint(endpoint);
                }

                if (config.getApiKey().equals("YOUR_API_KEY_HERE")) {
                    System.err.println("❌ API key not configured!");
                    System.err.println("Set DED_API_KEY environment variable or use -k option");
                    return 1;
                }

                Path inputPath = Paths.get(config.getOutputDir(), inputFile);
                if (!Files.exists(inputPath)) {
                    System.err.println("❌ Input file not found: " + inputPath.toAbsolutePath());
                    System.err.println("Generate fingerprints first using the 'generate' command");
                    return 1;
                }

                String jsonContent = Files.readString(inputPath);
                Gson gson = new GsonBuilder().disableHtmlEscaping().create();
                List<FingerprintGenerator.FingerprintSubmission> submissions =
                    gson.fromJson(jsonContent,
                        new com.google.gson.reflect.TypeToken<List<FingerprintGenerator.FingerprintSubmission>>(){}.getType());

                System.out.println("Submitting " + submissions.size() + " fingerprints to: " + config.getApiEndpoint());

                try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
                    HttpPost httpPost = new HttpPost(config.getApiEndpoint());
                    httpPost.setHeader("Content-Type", "application/json");
                    httpPost.setHeader("x-api-key", config.getApiKey());

                    String requestBody = gson.toJson(submissions);
                    httpPost.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));

                    try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                        int statusCode = response.getCode();
                        String responseBody = new String(response.getEntity().getContent().readAllBytes());

                        if (statusCode >= 200 && statusCode < 300) {
                            System.out.println("✅ Successfully submitted " + submissions.size() + " fingerprints");
                            System.out.println("   Status: " + statusCode);
                            if (!responseBody.isEmpty()) {
                                System.out.println("   Response: " + responseBody);
                            }
                            return 0;
                        } else {
                            System.err.println("❌ Submission failed with status: " + statusCode);
                            System.err.println("   Response: " + responseBody);
                            return 1;
                        }
                    }
                } catch (Exception httpEx) {
                    System.err.println("❌ HTTP request failed: " + httpEx.getMessage());
                    httpEx.printStackTrace();
                    return 1;
                }

            } catch (Exception e) {
                System.err.println("Error submitting fingerprints: " + e.getMessage());
                e.printStackTrace();
                return 1;
            }
        }
    }

    @Command(name = "all", description = "Generate and submit fingerprints")
    static class AllCommand implements Callable<Integer> {
        @Option(names = {"-c", "--count"}, description = "Number of fingerprints to generate", defaultValue = "5")
        private int count;

        @Option(names = {"-k", "--api-key"}, description = "Override API key")
        private String apiKey;

        @Option(names = {"--org-id"}, description = "Override organization ID")
        private String orgId;

        @Option(names = {"--tenant-id"}, description = "Override tenant ID")
        private String tenantId;

        @Override
        public Integer call() {
            System.out.println("Running full flow: Generate and Submit\n");

            GenerateCommand generateCmd = new GenerateCommand();
            generateCmd.count = count;
            generateCmd.noMetadata = false;
            generateCmd.orgId = orgId;
            generateCmd.tenantId = tenantId;
            generateCmd.verbose = true;

            System.out.println("Step 1: Generating fingerprints...");
            int genResult = generateCmd.call();
            if (genResult != 0) {
                return genResult;
            }

            System.out.println("\nStep 2: Submitting to API...");
            SubmitCommand submitCmd = new SubmitCommand();
            submitCmd.apiKey = apiKey;
            submitCmd.inputFile = "fingerprint_submissions.json";

            return submitCmd.call();
        }
    }
}