@echo off
REM DED .NET SDK Runner Script for Windows

:menu
cls
echo ===============================================================
echo      DED .NET SDK Runner
echo ===============================================================
echo.
echo Select an operation:
echo ----------------------------------------
echo 1) Generate fingerprints
echo 2) Submit fingerprints to API
echo 3) Generate and submit (full flow)
echo 4) Display SDK info
echo 5) Configure API key
echo 6) Build/Rebuild project
echo 7) Exit
echo.
set /p choice="Enter your choice [1-7]: "

if "%choice%"=="1" goto generate
if "%choice%"=="2" goto submit
if "%choice%"=="3" goto fullflow
if "%choice%"=="4" goto info
if "%choice%"=="5" goto configure
if "%choice%"=="6" goto build
if "%choice%"=="7" goto end

echo Invalid option. Please try again.
pause
goto menu

:generate
echo.
set /p count="How many fingerprints to generate? [default: 5]: "
if "%count%"=="" set count=5

set metadata=
set /p includemeta="Include metadata? (y/n) [default: y]: "
if /i "%includemeta%"=="n" set metadata=--no-metadata

echo.
echo Generating %count% fingerprints...
dotnet run -- generate --count %count% %metadata% --verbose

echo.
echo Generation complete!
pause
goto menu

:submit
echo.
echo Submitting fingerprints...
dotnet run -- submit --input fingerprint_submissions.json

echo.
echo Submission complete!
pause
goto menu

:fullflow
echo.
echo Running full flow: Generate and Submit
echo.
set /p count="How many fingerprints to generate? [default: 5]: "
if "%count%"=="" set count=5

echo.
echo Step 1: Generating %count% fingerprints...
dotnet run -- generate --count %count% --verbose

echo.
echo Step 2: Submitting to API...
dotnet run -- submit --input fingerprint_submissions.json

echo.
echo Full flow complete!
pause
goto menu

:info
echo.
dotnet run -- info
pause
goto menu

:configure
echo.
echo Current configuration file: config\config.json
echo.
set /p apikey="Enter new API key (or press Enter to keep current): "

if not "%apikey%"=="" (
    echo Updating API key...
    REM This is a simplified version - in production you'd want to properly update the JSON
    echo Please manually edit config\config.json to update your API key
    echo Your API key: %apikey%
)

pause
goto menu

:build
echo.
echo Building .NET project...
dotnet build --configuration Release

if %ERRORLEVEL% EQU 0 (
    echo.
    echo Build successful!
    echo.
    echo You can also create platform-specific executables:
    echo   - Windows: dotnet publish -c Release -r win-x64 --self-contained
    echo   - Linux:   dotnet publish -c Release -r linux-x64 --self-contained
    echo   - macOS:   dotnet publish -c Release -r osx-x64 --self-contained
) else (
    echo.
    echo Build failed!
)

pause
goto menu

:end
echo.
echo Goodbye!
exit /b 0