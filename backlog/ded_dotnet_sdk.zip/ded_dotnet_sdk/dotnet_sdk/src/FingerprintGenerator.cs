using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using NBitcoin;
using NBitcoin.Crypto;
using NBitcoin.Secp256k1;
using Newtonsoft.Json;
using Org.Webpki.JsonCanonicalizer;

namespace DedSdk
{
    public class FingerprintValue
    {
        [JsonProperty("orgId")]
        public string OrgId { get; set; } = "";

        [JsonProperty("tenantId")]
        public string TenantId { get; set; } = "";

        [JsonProperty("eventId")]
        public string EventId { get; set; } = "";

        [JsonProperty("documentId")]
        public string DocumentId { get; set; } = "";

        [JsonProperty("documentRef")]
        public string DocumentRef { get; set; } = "";

        [JsonProperty("timestamp")]
        public string Timestamp { get; set; } = "";

        [JsonProperty("version")]
        public int Version { get; set; }

        [JsonProperty("signerId", NullValueHandling = NullValueHandling.Ignore)]
        public string? SignerId { get; set; }
    }

    public class SignatureProof
    {
        [JsonProperty("id")]
        public string Id { get; set; } = "";

        [JsonProperty("signature")]
        public string Signature { get; set; } = "";

        [JsonProperty("algorithm")]
        public string Algorithm { get; set; } = "";
    }

    public class SignedFingerprint
    {
        [JsonProperty("content")]
        public FingerprintValue Content { get; set; } = new();

        [JsonProperty("proofs")]
        public List<SignatureProof> Proofs { get; set; } = new();
    }

    public class FingerprintMetadata
    {
        [JsonProperty("hash")]
        public string Hash { get; set; } = "";

        [JsonProperty("tags")]
        public Dictionary<string, string> Tags { get; set; } = new();
    }

    public class FingerprintSubmission
    {
        [JsonProperty("attestation")]
        public SignedFingerprint Attestation { get; set; } = new();

        [JsonProperty("metadata", NullValueHandling = NullValueHandling.Ignore)]
        public FingerprintMetadata? Metadata { get; set; }
    }

    public class FingerprintGenerator
    {
        private readonly string _orgId;
        private readonly string _tenantId;
        private readonly Key _privateKey;
        private readonly string _publicKeyHex;

        public FingerprintGenerator(string? orgId = null, string? tenantId = null, string? privateKeyHex = null)
        {
            _orgId = orgId ?? "11111111-1111-1111-1111-111111111111";
            _tenantId = tenantId ?? "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";

            if (!string.IsNullOrEmpty(privateKeyHex))
            {
                // Use provided private key
                _privateKey = new Key(Convert.FromHexString(privateKeyHex));
            }
            else
            {
                // Generate new private key
                _privateKey = new Key();
            }

            // Get public key in uncompressed format without 0x04 prefix
            // NBitcoin PubKey.ToHex() gives compressed (33 bytes)
            // We need uncompressed (65 bytes: 0x04 + 32 bytes x + 32 bytes y)
            var pubKey = _privateKey.PubKey;

            // Get uncompressed public key using secp256k1 library directly
            // Create ECPubKey from the NBitcoin PubKey
            var pubKeyBytes = pubKey.ToBytes(); // Get compressed bytes
            ECPubKey ecPubKey = Context.Instance.CreatePubKey(pubKeyBytes);

            // Get uncompressed format (65 bytes with 0x04 prefix)
            byte[] uncompressedBytes = new byte[65];
            ecPubKey.WriteToSpan(false, uncompressedBytes.AsSpan(), out int length); // false = uncompressed

            // Remove the 0x04 prefix to get just x||y coordinates (64 bytes)
            var uncompressedKey = new byte[64];
            if (uncompressedBytes.Length >= 65 && uncompressedBytes[0] == 0x04)
            {
                Array.Copy(uncompressedBytes, 1, uncompressedKey, 0, 64);
            }
            else
            {
                throw new Exception($"Invalid uncompressed key format. Length: {uncompressedBytes.Length}, First byte: {uncompressedBytes[0]:X2}");
            }

            _publicKeyHex = Convert.ToHexString(uncompressedKey).ToLower();
        }

        private string ComputeHash(FingerprintValue value)
        {
            // Canonicalize JSON using RFC 8785
            var json = JsonConvert.SerializeObject(value);
            var canonicalizer = new JsonCanonicalizer(json);
            var canonical = canonicalizer.GetEncodedString();

            // Compute SHA-256
            using var sha256 = System.Security.Cryptography.SHA256.Create();
            var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(canonical));
            return Convert.ToHexString(hashBytes).ToLower();
        }

        private SignedFingerprint SignFingerprint(FingerprintValue value)
        {
            // Step 1: Canonicalize JSON (RFC 8785)
            var json = JsonConvert.SerializeObject(value);
            var canonicalizer = new JsonCanonicalizer(json);
            var canonical = canonicalizer.GetEncodedString();

            // Step 2: Compute SHA-256 hash
            using var sha256 = System.Security.Cryptography.SHA256.Create();
            var sha256Hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(canonical));

            // Step 3: Convert hash to hex string
            var hashHex = Convert.ToHexString(sha256Hash).ToLower();

            // Step 4: Treat hex string as UTF-8 bytes
            var hashBytesForSigning = Encoding.UTF8.GetBytes(hashHex);

            // Step 5: SHA-512 hash of the hex bytes
            using var sha512 = SHA512.Create();
            var sha512Hash = sha512.ComputeHash(hashBytesForSigning);
            var truncatedHash = sha512Hash.Take(32).ToArray(); // Truncate for secp256k1

            // Step 6: Sign with ECDSA and get DER format
            ECPrivKey privKey = Context.Instance.CreateECPrivKey(_privateKey.ToBytes());

            // Create signature - pass truncatedHash as ReadOnlySpan<byte>
            ReadOnlySpan<byte> hashSpan = truncatedHash.AsSpan();
            if (!privKey.TrySignECDSA(hashSpan, out var signature))
            {
                throw new Exception("Failed to create signature");
            }

            // Convert to DER format
            byte[] derSignature = new byte[72];
            signature!.WriteDerToSpan(derSignature.AsSpan(), out int derLength);
            var signatureHex = Convert.ToHexString(derSignature[..derLength]).ToLower();

            return new SignedFingerprint
            {
                Content = value,
                Proofs = new List<SignatureProof>
                {
                    new SignatureProof
                    {
                        Id = _publicKeyHex,
                        Signature = signatureHex,
                        Algorithm = "SECP256K1_RFC8785_V1"
                    }
                }
            };
        }

        public FingerprintSubmission GenerateSubmission(int index, bool includeMetadata)
        {
            // Generate IDs
            var eventId = Guid.NewGuid().ToString();
            var documentId = $"doc-{(index + 1):D3}";

            // Generate document reference (hash of document ID)
            using var sha256 = System.Security.Cryptography.SHA256.Create();
            var docHash = sha256.ComputeHash(Encoding.UTF8.GetBytes(documentId));
            var documentRef = Convert.ToHexString(docHash).ToLower();

            // Generate timestamp - 5 minutes in the past minus index * 60 seconds
            var timestamp = DateTime.UtcNow
                .AddMinutes(-5)
                .AddMinutes(-index);

            // Format with millisecond precision
            var timestampStr = timestamp.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'");

            var value = new FingerprintValue
            {
                OrgId = _orgId,
                TenantId = _tenantId,
                EventId = eventId,
                DocumentId = documentId,
                DocumentRef = documentRef,
                Timestamp = timestampStr,
                Version = 1,
                SignerId = null
            };

            // Sign the fingerprint
            var signed = SignFingerprint(value);

            var submission = new FingerprintSubmission
            {
                Attestation = signed
            };

            // Add metadata if requested
            if (includeMetadata)
            {
                var hash = ComputeHash(value);

                var metadata = new FingerprintMetadata
                {
                    Hash = hash,
                    Tags = new Dictionary<string, string>
                    {
                        ["generator"] = "DotNet-SDK"
                    }
                };

                if (index % 2 == 0)
                {
                    metadata.Tags["index"] = index.ToString();
                    metadata.Tags["category"] = "batch-1";
                    if (index % 3 == 0)
                    {
                        metadata.Tags["priority"] = "high";
                    }
                }

                submission.Metadata = metadata;
            }

            return submission;
        }

        public List<FingerprintSubmission> GenerateBatch(int count, bool includeMetadata)
        {
            var submissions = new List<FingerprintSubmission>();
            for (int i = 0; i < count; i++)
            {
                submissions.Add(GenerateSubmission(i, includeMetadata));
            }
            return submissions;
        }

        public Dictionary<string, object> GetKeyInfo()
        {
            return new Dictionary<string, object>
            {
                ["publicKey"] = _publicKeyHex,
                ["publicKeyLength"] = _publicKeyHex.Length,
                ["orgId"] = _orgId,
                ["tenantId"] = _tenantId
            };
        }
    }
}