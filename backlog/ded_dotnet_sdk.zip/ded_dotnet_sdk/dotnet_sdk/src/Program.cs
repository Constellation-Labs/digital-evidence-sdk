using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using CommandLine;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestSharp;

namespace DedSdk
{
    public class Config
    {
        public string ApiKey { get; set; } = "YOUR_API_KEY_HERE";
        public string ApiEndpoint { get; set; } = "https://de-api.constellationnetwork.io/v1/fingerprints";
        public string OrgId { get; set; } = "11111111-1111-1111-1111-111111111111";
        public string TenantId { get; set; } = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa";
        public string OutputDir { get; set; } = "./output";
        public string? PrivateKey { get; set; }
    }

    [Verb("generate", HelpText = "Generate signed fingerprints")]
    public class GenerateOptions
    {
        [Option('c', "count", Default = 5, HelpText = "Number of fingerprints to generate")]
        public int Count { get; set; }

        [Option('o', "output", Default = "fingerprint_submissions.json", HelpText = "Output file path")]
        public string Output { get; set; } = "";

        [Option("no-metadata", Default = false, HelpText = "Generate without metadata")]
        public bool NoMetadata { get; set; }

        [Option('v', "verbose", Default = false, HelpText = "Verbose output")]
        public bool Verbose { get; set; }

        [Option("org", HelpText = "Override organization ID")]
        public string? OrgId { get; set; }

        [Option("tenant", HelpText = "Override tenant ID")]
        public string? TenantId { get; set; }
    }

    [Verb("submit", HelpText = "Submit fingerprints to the API")]
    public class SubmitOptions
    {
        [Option('i', "input", Default = "fingerprint_submissions.json", HelpText = "Input file path")]
        public string Input { get; set; } = "";

        [Option('k', "api-key", HelpText = "API key")]
        public string? ApiKey { get; set; }

        [Option('e', "endpoint", HelpText = "API endpoint")]
        public string? Endpoint { get; set; }
    }

    [Verb("info", HelpText = "Display SDK information")]
    public class InfoOptions { }

    [Verb("config", HelpText = "Display current configuration")]
    public class ConfigOptions { }

    class Program
    {
        private static Config LoadConfig()
        {
            var configPath = Path.Combine("config", "config.json");
            Config config;

            if (File.Exists(configPath))
            {
                var json = File.ReadAllText(configPath);
                config = JsonConvert.DeserializeObject<Config>(json) ?? new Config();
            }
            else
            {
                // Create default config if it doesn't exist
                config = new Config();
                Directory.CreateDirectory("config");
                File.WriteAllText(configPath, JsonConvert.SerializeObject(config, Formatting.Indented));
                Console.WriteLine($"Created default configuration at: {configPath}");
            }

            // Apply environment variable overrides
            config = ApplyEnvironmentOverrides(config);

            return config;
        }

        private static Config ApplyEnvironmentOverrides(Config config)
        {
            // Override with environment variables if they exist
            var apiKey = Environment.GetEnvironmentVariable("DED_API_KEY");
            if (!string.IsNullOrEmpty(apiKey))
                config.ApiKey = apiKey;

            var apiEndpoint = Environment.GetEnvironmentVariable("DED_API_ENDPOINT");
            if (!string.IsNullOrEmpty(apiEndpoint))
                config.ApiEndpoint = apiEndpoint;

            var orgId = Environment.GetEnvironmentVariable("DED_ORG_ID");
            if (!string.IsNullOrEmpty(orgId))
                config.OrgId = orgId;

            var tenantId = Environment.GetEnvironmentVariable("DED_TENANT_ID");
            if (!string.IsNullOrEmpty(tenantId))
                config.TenantId = tenantId;

            var outputDir = Environment.GetEnvironmentVariable("DED_OUTPUT_DIR");
            if (!string.IsNullOrEmpty(outputDir))
                config.OutputDir = outputDir;

            var privateKey = Environment.GetEnvironmentVariable("DED_PRIVATE_KEY");
            if (!string.IsNullOrEmpty(privateKey))
                config.PrivateKey = privateKey;

            return config;
        }

        static int Main(string[] args)
        {
            var config = LoadConfig();

            return Parser.Default.ParseArguments<GenerateOptions, SubmitOptions, InfoOptions, ConfigOptions>(args)
                .MapResult(
                    (GenerateOptions opts) => RunGenerate(opts, config),
                    (SubmitOptions opts) => RunSubmit(opts, config),
                    (InfoOptions opts) => RunInfo(config),
                    (ConfigOptions opts) => RunConfig(config),
                    errs => 1);
        }

        private static int RunGenerate(GenerateOptions opts, Config config)
        {
            // Use overrides if provided
            var orgId = opts.OrgId ?? config.OrgId;
            var tenantId = opts.TenantId ?? config.TenantId;

            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║     Generating Signed Fingerprints                          ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.WriteLine("Configuration:");
            Console.WriteLine($"  • Count: {opts.Count} fingerprints");
            Console.WriteLine($"  • Output: {opts.Output}");
            Console.WriteLine($"  • Metadata: {!opts.NoMetadata}");
            Console.WriteLine($"  • Organization: {orgId}");
            Console.WriteLine($"  • Tenant: {tenantId}");
            Console.WriteLine();

            try
            {
                // Create generator with optional private key
                var generator = config.PrivateKey != null
                    ? new FingerprintGenerator(orgId, tenantId, config.PrivateKey)
                    : new FingerprintGenerator(orgId, tenantId);

                // Generate fingerprints
                var submissions = generator.GenerateBatch(opts.Count, !opts.NoMetadata);

                // Ensure output directory exists
                Directory.CreateDirectory(config.OutputDir);

                // Write to file
                var outputPath = Path.Combine(config.OutputDir, opts.Output);
                var json = JsonConvert.SerializeObject(submissions, Formatting.Indented);
                File.WriteAllText(outputPath, json);

                var keyInfo = generator.GetKeyInfo();
                var pubKey = keyInfo["publicKey"].ToString()!;
                if (pubKey.Length > 32)
                {
                    pubKey = pubKey.Substring(0, 32) + "...";
                }

                Console.WriteLine($"✅ Generated {opts.Count} signed fingerprints");
                Console.WriteLine($"📁 Output saved to: {outputPath}");
                Console.WriteLine($"🔑 Public Key: {pubKey}");
                Console.WriteLine($"🏢 Organization: {keyInfo["orgId"]}");
                Console.WriteLine($"👥 Tenant: {keyInfo["tenantId"]}");

                if (opts.Verbose)
                {
                    Console.WriteLine("\n📝 Submission Details:");
                    for (int i = 0; i < submissions.Count; i++)
                    {
                        var sub = submissions[i];
                        Console.WriteLine($"\n  {i + 1}. Event ID: {sub.Attestation.Content.EventId}");
                        Console.WriteLine($"     Document: {sub.Attestation.Content.DocumentId}");
                        Console.WriteLine($"     Version: {sub.Attestation.Content.Version}");
                        if (sub.Metadata != null && sub.Metadata.Tags.Count > 0)
                        {
                            var tags = string.Join(", ", sub.Metadata.Tags.Select(kv => $"{kv.Key}={kv.Value}"));
                            Console.WriteLine($"     Tags: {tags}");
                        }
                    }
                }

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
                return 1;
            }
        }

        private static int RunSubmit(SubmitOptions opts, Config config)
        {
            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║     Submitting Fingerprints to API                          ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.WriteLine();

            var apiKey = opts.ApiKey ?? config.ApiKey;
            var endpoint = opts.Endpoint ?? config.ApiEndpoint;

            // Check for API key
            if (string.IsNullOrEmpty(apiKey) || apiKey == "YOUR_API_KEY_HERE")
            {
                Console.WriteLine("❌ Error: API key not configured");
                Console.WriteLine("   Please set it in config/config.json or use --api-key flag");
                return 1;
            }

            // Check input file exists
            var inputPath = Path.Combine(config.OutputDir, opts.Input);
            if (!File.Exists(inputPath))
            {
                Console.WriteLine($"❌ Error: {inputPath} not found");
                Console.WriteLine("   Please run 'generate' command first");
                return 1;
            }

            Console.WriteLine("Configuration:");
            Console.WriteLine($"  • API Endpoint: {endpoint}");
            Console.WriteLine($"  • API Key: {apiKey.Substring(0, Math.Min(10, apiKey.Length))}...");
            Console.WriteLine($"  • Input File: {opts.Input}");
            Console.WriteLine();
            Console.WriteLine("Submitting...");

            try
            {
                // Read input file
                var json = File.ReadAllText(inputPath);

                // Send request using RestSharp
                var client = new RestClient(endpoint);
                var request = new RestRequest("", Method.Post);
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("x-api-key", apiKey);
                request.AddStringBody(json, DataFormat.Json);

                var response = client.Execute(request);

                Console.WriteLine();
                if (response.IsSuccessful)
                {
                    Console.WriteLine($"✅ Submission successful! (HTTP {(int)response.StatusCode})");
                }
                else
                {
                    Console.WriteLine($"❌ Submission failed (HTTP {(int)response.StatusCode})");
                }

                Console.WriteLine("Response:");
                if (!string.IsNullOrEmpty(response.Content))
                {
                    try
                    {
                        var responseObj = JsonConvert.DeserializeObject(response.Content);
                        Console.WriteLine(JsonConvert.SerializeObject(responseObj, Formatting.Indented));
                    }
                    catch
                    {
                        Console.WriteLine(response.Content);
                    }
                }

                return response.IsSuccessful ? 0 : 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
                return 1;
            }
        }

        private static int RunInfo(Config config)
        {
            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║     DED .NET SDK Information                                ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.WriteLine();

            var generator = new FingerprintGenerator(config.OrgId, config.TenantId);
            var keyInfo = generator.GetKeyInfo();

            Console.WriteLine("Configuration:");
            Console.WriteLine($"  • Organization ID: {keyInfo["orgId"]}");
            Console.WriteLine($"  • Tenant ID: {keyInfo["tenantId"]}");
            Console.WriteLine($"  • API Endpoint: {config.ApiEndpoint}");
            Console.WriteLine();
            Console.WriteLine("Generated Key Info:");
            Console.WriteLine($"  • Public Key Length: {keyInfo["publicKeyLength"]} characters");
            Console.WriteLine("  • Algorithm: SECP256K1_RFC8785_V1");
            Console.WriteLine();
            Console.WriteLine("Runtime Information:");
            Console.WriteLine($"  • .NET Version: {Environment.Version}");
            Console.WriteLine($"  • OS: {Environment.OSVersion}");

            return 0;
        }

        private static int RunConfig(Config config)
        {
            Console.WriteLine("╔══════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║              Current SDK Configuration                      ║");
            Console.WriteLine("╚══════════════════════════════════════════════════════════════╝");
            Console.WriteLine();
            Console.WriteLine("Configuration Sources (priority order):");
            Console.WriteLine("  1. Environment Variables (DED_* prefix)");
            Console.WriteLine("  2. Config File (config.json)");
            Console.WriteLine("  3. Default Values");
            Console.WriteLine();
            Console.WriteLine("Current Settings:");
            Console.WriteLine("─────────────────");

            // Display API Key (masked)
            if (string.IsNullOrEmpty(config.ApiKey) || config.ApiKey == "YOUR_API_KEY_HERE")
            {
                Console.WriteLine("  API Key:       <not configured>");
            }
            else if (config.ApiKey.Length > 10)
            {
                Console.WriteLine($"  API Key:       {config.ApiKey.Substring(0, 10)}...");
            }
            else
            {
                Console.WriteLine("  API Key:       <configured>");
            }

            // Display other settings
            Console.WriteLine($"  API Endpoint:  {config.ApiEndpoint}");
            Console.WriteLine($"  Organization:  {config.OrgId}");
            Console.WriteLine($"  Tenant:        {config.TenantId}");
            Console.WriteLine($"  Output Dir:    {config.OutputDir}");

            // Display private key status
            if (string.IsNullOrEmpty(config.PrivateKey))
            {
                Console.WriteLine("  Private Key:   <will generate new key>");
            }
            else
            {
                Console.WriteLine("  Private Key:   <configured>");
            }

            Console.WriteLine();
            Console.WriteLine("Environment Variables:");
            Console.WriteLine("──────────────────────");

            var envVars = new[] { "DED_API_KEY", "DED_API_ENDPOINT", "DED_ORG_ID", "DED_TENANT_ID", "DED_PRIVATE_KEY", "DED_OUTPUT_DIR" };
            foreach (var envVar in envVars)
            {
                var value = Environment.GetEnvironmentVariable(envVar);
                if (!string.IsNullOrEmpty(value))
                {
                    if (envVar == "DED_API_KEY" && value.Length > 10)
                    {
                        Console.WriteLine($"  {envVar} = {value.Substring(0, 10)}...");
                    }
                    else if (envVar == "DED_PRIVATE_KEY")
                    {
                        Console.WriteLine($"  {envVar} = <set>");
                    }
                    else
                    {
                        Console.WriteLine($"  {envVar} = {value}");
                    }
                }
                else
                {
                    Console.WriteLine($"  {envVar} = <not set>");
                }
            }

            return 0;
        }
    }
}