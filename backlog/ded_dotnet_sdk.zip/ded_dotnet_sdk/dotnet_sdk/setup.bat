@echo off
REM DED .NET SDK Setup Script for Windows

echo ===============================================================
echo      DED .NET SDK Setup
echo ===============================================================
echo.

REM Check for .NET SDK
where dotnet >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [OK] .NET SDK is installed:
    dotnet --version
) else (
    echo [ERROR] .NET SDK is not installed
    echo.
    echo Please download and install .NET SDK from:
    echo https://dotnet.microsoft.com/download
    echo.
    pause
    exit /b 1
)

echo.
echo Restoring NuGet packages...
dotnet restore

echo.
echo Building the SDK...
dotnet build --configuration Release

if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Build successful!
    echo.
    echo Binary location: bin\Release\net8.0\ded-fingerprint.exe
    echo.
    echo Configuration Setup:
    echo ----------------------------------------
    echo 1. Edit config\config.json
    echo 2. Replace 'YOUR_API_KEY_HERE' with your actual API key
    echo.
    echo Usage Examples:
    echo ----------------------------------------
    echo Generate fingerprints:
    echo   dotnet run -- generate --count 5
    echo.
    echo Submit to API:
    echo   dotnet run -- submit --input fingerprint_submissions.json
    echo.
    echo Display info:
    echo   dotnet run -- info
    echo.
    echo Or use the compiled binary directly:
    echo   bin\Release\net8.0\ded-fingerprint.exe generate --count 5
    echo.
) else (
    echo.
    echo [ERROR] Build failed. Please check the errors above.
    pause
    exit /b 1
)

pause