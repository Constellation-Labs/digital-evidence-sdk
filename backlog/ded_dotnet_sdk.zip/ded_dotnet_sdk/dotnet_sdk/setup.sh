#!/bin/bash

# DED .NET SDK Setup Script

set -e  # Exit on error

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     DED .NET SDK Setup                                      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check for .NET SDK installation
check_dotnet() {
    if command -v dotnet &> /dev/null; then
        echo "✅ .NET SDK is installed: $(dotnet --version)"
        return 0
    else
        echo "❌ .NET SDK is not installed"
        return 1
    fi
}

# Install .NET SDK
install_dotnet() {
    echo "Installing .NET SDK..."

    # Check OS
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux - using Microsoft's install script
        wget https://dot.net/v1/dotnet-install.sh -O dotnet-install.sh
        chmod +x dotnet-install.sh
        ./dotnet-install.sh --channel 8.0
        rm dotnet-install.sh

        # Add to PATH
        export DOTNET_ROOT=$HOME/.dotnet
        export PATH=$PATH:$DOTNET_ROOT

        echo ""
        echo "Add these lines to your ~/.bashrc or ~/.zshrc:"
        echo "export DOTNET_ROOT=\$HOME/.dotnet"
        echo "export PATH=\$PATH:\$DOTNET_ROOT"

    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # Mac OSX
        if command -v brew &> /dev/null; then
            brew install --cask dotnet-sdk
        else
            echo "Installing via direct download..."
            echo "Please download and install from: https://dotnet.microsoft.com/download"
            exit 1
        fi
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
        # Windows
        echo "Please download and install .NET SDK from:"
        echo "https://dotnet.microsoft.com/download"
        exit 1
    else
        echo "Unsupported OS. Please install .NET SDK manually from:"
        echo "https://dotnet.microsoft.com/download"
        exit 1
    fi

    echo "✅ .NET SDK installed successfully"
}

# Main setup
main() {
    echo "Checking prerequisites..."
    echo ""

    # Check .NET
    if ! check_dotnet; then
        read -p "Would you like to install .NET SDK? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_dotnet
        else
            echo "⚠️  .NET SDK is required to build the project"
            echo "Please install from: https://dotnet.microsoft.com/download"
            exit 1
        fi
    fi

    echo ""
    echo "Restoring NuGet packages..."
    dotnet restore

    echo ""
    echo "Building the SDK..."
    dotnet build --configuration Release

    if [ $? -eq 0 ]; then
        echo ""
        echo "✅ Build successful!"
        echo ""
        echo "Binary location: bin/Release/net8.0/ded-fingerprint"
        echo ""
        echo "Configuration Setup:"
        echo "──────────────────────────────────────"
        echo "1. Edit config/config.json"
        echo "2. Replace 'YOUR_API_KEY_HERE' with your actual API key"
        echo ""
        echo "Usage Examples:"
        echo "──────────────────────────────────────"
        echo "• Generate fingerprints:"
        echo "  dotnet run -- generate --count 5"
        echo ""
        echo "• Submit to API:"
        echo "  dotnet run -- submit --input fingerprint_submissions.json"
        echo ""
        echo "• Display info:"
        echo "  dotnet run -- info"
        echo ""
        echo "Or use the compiled binary directly:"
        echo "  ./bin/Release/net8.0/ded-fingerprint generate --count 5"
        echo ""
        echo "To create a self-contained executable:"
        echo "  dotnet publish -c Release -r linux-x64 --self-contained"
        echo "  dotnet publish -c Release -r win-x64 --self-contained"
        echo "  dotnet publish -c Release -r osx-x64 --self-contained"
        echo ""
    else
        echo ""
        echo "❌ Build failed. Please check the errors above."
        exit 1
    fi
}

main "$@"