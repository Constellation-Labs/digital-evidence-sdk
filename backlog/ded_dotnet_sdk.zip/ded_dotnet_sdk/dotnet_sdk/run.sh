#!/bin/bash

# DED .NET SDK Runner Script

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
CONFIG_FILE="config/config.json"
OUTPUT_DIR="output"
BINARY="./bin/Release/net8.0/ded-fingerprint"

# Display header
display_header() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║     DED .NET SDK Runner                                     ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Check binary exists
check_binary() {
    if [ ! -f "$BINARY" ] && [ ! -f "$BINARY.exe" ]; then
        echo -e "${YELLOW}Binary not found. Building...${NC}"
        dotnet build --configuration Release
        if [ $? -ne 0 ]; then
            echo -e "${RED}Build failed!${NC}"
            exit 1
        fi
    fi
}

# Check if dotnet is available
check_dotnet() {
    if ! command -v dotnet &> /dev/null; then
        echo -e "${RED}❌ .NET SDK is not installed${NC}"
        echo "Please run ./setup.sh to install .NET SDK"
        exit 1
    fi
}

# Determine how to run the app
get_run_command() {
    if [ -f "$BINARY" ]; then
        echo "$BINARY"
    elif [ -f "$BINARY.exe" ]; then
        echo "$BINARY.exe"
    else
        echo "dotnet run --"
    fi
}

# Load API key from config
load_api_key() {
    if [ -f "$CONFIG_FILE" ]; then
        API_KEY=$(grep "apiKey" "$CONFIG_FILE" | cut -d '"' -f 4)
        if [ "$API_KEY" == "YOUR_API_KEY_HERE" ] || [ -z "$API_KEY" ]; then
            return 1
        fi
        return 0
    fi
    return 1
}

# Display menu
display_menu() {
    echo "Select an operation:"
    echo "──────────────────────────────────────"
    echo "1) Generate fingerprints"
    echo "2) Submit fingerprints to API"
    echo "3) Generate and submit (full flow)"
    echo "4) Display SDK info"
    echo "5) Show configuration"
    echo "6) Configure SDK (API key, Org, Tenant)"
    echo "7) Build/Rebuild project"
    echo "8) Exit"
    echo ""
    read -p "Enter your choice [1-8]: " choice
}

# Generate fingerprints
generate_fingerprints() {
    local cmd=$(get_run_command)

    echo ""
    read -p "How many fingerprints to generate? [default: 5]: " count
    count=${count:-5}

    read -p "Include metadata? (y/n) [default: y]: " include_metadata
    if [[ "$include_metadata" =~ ^[Nn]$ ]]; then
        metadata_flag="--no-metadata"
    else
        metadata_flag=""
    fi

    echo -e "\n${GREEN}Generating $count fingerprints...${NC}"
    $cmd generate --count "$count" $metadata_flag --verbose

    echo -e "\n${GREEN}✅ Generation complete!${NC}"
}

# Submit fingerprints
submit_fingerprints() {
    local cmd=$(get_run_command)

    if ! load_api_key; then
        echo -e "${RED}API key not configured!${NC}"
        echo "Please configure your API key first (option 5)"
        return 1
    fi

    local input_file="$OUTPUT_DIR/fingerprint_submissions.json"

    if [ ! -f "$input_file" ]; then
        echo -e "${YELLOW}No fingerprints found to submit.${NC}"
        echo "Please generate fingerprints first (option 1)"
        return 1
    fi

    echo -e "\n${GREEN}Submitting fingerprints...${NC}"
    $cmd submit --input "fingerprint_submissions.json"

    echo -e "\n${GREEN}✅ Submission complete!${NC}"
}

# Show configuration
show_configuration() {
    local cmd=$(get_run_command)
    echo ""
    $cmd config
}

# Configure SDK (enhanced)
configure_sdk() {
    echo ""
    echo -e "${BLUE}SDK Configuration${NC}"
    echo "────────────────────"
    echo ""
    echo "You can configure the SDK using:"
    echo ""
    echo "1. Environment Variables (Recommended):"
    echo "   • DED_API_KEY        - Your API key"
    echo "   • DED_ORG_ID         - Organization ID"
    echo "   • DED_TENANT_ID      - Tenant ID"
    echo "   • DED_API_ENDPOINT   - API endpoint URL"
    echo "   • DED_PRIVATE_KEY    - Private key (hex)"
    echo ""
    echo "2. Config File (config/config.json)"
    echo ""
    echo "3. Command Line Arguments:"
    echo "   • --org and --tenant for generate command"
    echo "   • --api-key for submit command"
    echo ""

    echo "Would you like to:"
    echo "1) Set environment variables"
    echo "2) Edit config file"
    echo "3) Back to main menu"
    echo ""
    read -p "Enter choice [1-3]: " config_choice

    case $config_choice in
        1)
            echo ""
            echo "Setting environment variables for this session:"
            echo ""

            read -p "Enter API Key (or press Enter to skip): " api_key
            if [ -n "$api_key" ]; then
                export DED_API_KEY="$api_key"
                echo -e "${GREEN}✓ DED_API_KEY set${NC}"
            fi

            read -p "Enter Organization ID (or press Enter to skip): " org_id
            if [ -n "$org_id" ]; then
                export DED_ORG_ID="$org_id"
                echo -e "${GREEN}✓ DED_ORG_ID set${NC}"
            fi

            read -p "Enter Tenant ID (or press Enter to skip): " tenant_id
            if [ -n "$tenant_id" ]; then
                export DED_TENANT_ID="$tenant_id"
                echo -e "${GREEN}✓ DED_TENANT_ID set${NC}"
            fi

            echo ""
            echo -e "${GREEN}Environment variables set for this session${NC}"
            echo "To make them permanent, add export commands to your shell profile"
            ;;
        2)
            configure_api_key
            ;;
        3)
            return
            ;;
        *)
            echo -e "${RED}Invalid choice${NC}"
            ;;
    esac
}

# Configure API key
configure_api_key() {
    echo ""
    echo "Current configuration file: $CONFIG_FILE"

    if load_api_key && [ "$API_KEY" != "YOUR_API_KEY_HERE" ]; then
        echo -e "Current API key: ${YELLOW}${API_KEY:0:10}...${NC} (truncated for security)"
    else
        echo -e "${YELLOW}API key not configured${NC}"
    fi

    echo ""
    read -p "Enter new API key (or press Enter to keep current): " new_key

    if [ -n "$new_key" ]; then
        # Update config file using sed
        if [ -f "$CONFIG_FILE" ]; then
            # Create temporary file with updated API key
            sed "s/\"apiKey\": \".*\"/\"apiKey\": \"$new_key\"/" "$CONFIG_FILE" > "$CONFIG_FILE.tmp"
            mv "$CONFIG_FILE.tmp" "$CONFIG_FILE"
            echo -e "${GREEN}✅ API key updated successfully${NC}"
        else
            echo -e "${RED}Config file not found!${NC}"
            return 1
        fi
    else
        echo "API key unchanged"
    fi
}

# Display SDK info
display_info() {
    local cmd=$(get_run_command)
    echo ""
    $cmd info
}

# Build project
build_project() {
    echo -e "\n${GREEN}Building .NET project...${NC}"
    dotnet build --configuration Release

    if [ $? -eq 0 ]; then
        echo -e "\n${GREEN}✅ Build successful!${NC}"
        echo ""
        echo "You can also create platform-specific executables:"
        echo "  • Linux:   dotnet publish -c Release -r linux-x64 --self-contained"
        echo "  • Windows: dotnet publish -c Release -r win-x64 --self-contained"
        echo "  • macOS:   dotnet publish -c Release -r osx-x64 --self-contained"
    else
        echo -e "\n${RED}❌ Build failed!${NC}"
    fi
}

# Full flow
full_flow() {
    local cmd=$(get_run_command)

    echo -e "\n${BLUE}Running full flow: Generate and Submit${NC}\n"

    # Generate
    read -p "How many fingerprints to generate? [default: 5]: " count
    count=${count:-5}

    echo -e "\n${GREEN}Step 1: Generating $count fingerprints...${NC}"
    $cmd generate --count "$count" --verbose

    # Submit
    if load_api_key; then
        echo -e "\n${GREEN}Step 2: Submitting to API...${NC}"
        $cmd submit --input "fingerprint_submissions.json"
        echo -e "\n${GREEN}✅ Full flow complete!${NC}"
    else
        echo -e "\n${YELLOW}⚠️  API key not configured. Skipping submission.${NC}"
        echo "Run option 5 to configure API key, then option 2 to submit."
    fi
}

# Main function
main() {
    display_header
    check_dotnet
    check_binary

    while true; do
        display_menu

        case $choice in
            1)
                generate_fingerprints
                ;;
            2)
                submit_fingerprints
                ;;
            3)
                full_flow
                ;;
            4)
                display_info
                ;;
            5)
                show_configuration
                ;;
            6)
                configure_sdk
                ;;
            7)
                build_project
                ;;
            8)
                echo -e "\n${GREEN}Goodbye!${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Invalid option. Please try again.${NC}"
                ;;
        esac

        echo ""
        read -p "Press Enter to continue..."
        echo ""
    done
}

# Run main function
main "$@"