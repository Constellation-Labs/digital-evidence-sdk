# DED .NET SDK

.NET SDK for generating and submitting cryptographically signed fingerprints to the DED (Digital Evidence) Metagraph.

## Features

- ✨ Generate SECP256K1 signed fingerprints with RFC 8785 JSON canonicalization
- 🔐 DER-encoded ECDSA signatures compatible with the DED API
- 📦 Batch generation with optional metadata
- 🚀 Cross-platform CLI (Windows, macOS, Linux)
- 🔧 JSON configuration file

## Requirements

- .NET 8.0 SDK or later
- Works on Windows, macOS, and Linux

## Installation

### Prerequisites

Install .NET SDK from [Microsoft's .NET Download page](https://dotnet.microsoft.com/download)

### Quick Setup

#### Windows
```cmd
setup.bat
```

#### macOS/Linux
```bash
chmod +x setup.sh
./setup.sh
```

### Manual Build
```bash
# Restore packages
dotnet restore

# Build the project
dotnet build --configuration Release
```

## Configuration

Edit `config/config.json` to set your API key and customize settings:

```json
{
  "apiKey": "YOUR_API_KEY_HERE",
  "apiEndpoint": "https://de-api.constellationnetwork.io/v1/fingerprints",
  "orgId": "11111111-1111-1111-1111-111111111111",
  "tenantId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
  "outputDir": "./output"
}
```

## Usage

### Interactive Runner

#### Windows
```cmd
run.bat
```

#### macOS/Linux
```bash
chmod +x run.sh
./run.sh
```

The runner provides a menu-driven interface for:
- Generating fingerprints
- Submitting to the API
- Running the full flow (generate + submit)
- Configuring your API key
- Building the project

### Command Line Usage

#### Generate Fingerprints

```bash
# Generate 5 fingerprints with metadata (default)
dotnet run -- generate

# Generate 10 fingerprints without metadata
dotnet run -- generate --count 10 --no-metadata

# Generate with verbose output
dotnet run -- generate --verbose

# Using the compiled binary
./bin/Release/net8.0/ded-fingerprint generate --count 5
```

#### Submit to API

```bash
# Submit using config file settings
dotnet run -- submit

# Submit with custom API key
dotnet run -- submit --api-key "your_api_key_here"

# Submit from specific file
dotnet run -- submit --input fingerprint_submissions.json
```

#### Display SDK Info

```bash
dotnet run -- info
```

## Creating Self-Contained Executables

Create platform-specific executables that don't require .NET runtime:

```bash
# Windows (64-bit)
dotnet publish -c Release -r win-x64 --self-contained

# Linux (64-bit)
dotnet publish -c Release -r linux-x64 --self-contained

# macOS (64-bit)
dotnet publish -c Release -r osx-x64 --self-contained

# macOS (Apple Silicon)
dotnet publish -c Release -r osx-arm64 --self-contained
```

The executables will be in `bin/Release/net8.0/{runtime}/publish/`

## Project Structure

```
dotnet_sdk/
├── DedSdk.csproj       # Project file with dependencies
├── config/
│   └── config.json     # Configuration file
├── src/
│   ├── Program.cs      # CLI entry point
│   └── FingerprintGenerator.cs  # Core generation logic
├── output/             # Generated fingerprint files
├── setup.sh           # Setup script (Unix)
├── setup.bat          # Setup script (Windows)
├── run.sh             # Runner script (Unix)
├── run.bat            # Runner script (Windows)
└── README.md          # This file
```

## Technical Details

### Signing Algorithm

The SDK implements the SECP256K1_RFC8785_V1 signature algorithm:

1. **Canonicalization**: JSON is canonicalized according to RFC 8785
2. **Hashing**: SHA-256 hash of the canonical JSON
3. **Double-Hash Protocol**:
   - Convert SHA-256 hash to hex string
   - Treat hex string as UTF-8 bytes
   - Apply SHA-512 and truncate to 32 bytes
4. **Signing**: ECDSA signature with secp256k1, output in DER format

### Dependencies

- **NBitcoin**: Bitcoin library providing secp256k1 implementation
- **NBitcoin.Secp256k1**: Native secp256k1 bindings for performance
- **JsonCanonicalizer**: RFC 8785 JSON canonicalization
- **Newtonsoft.Json**: JSON serialization
- **CommandLineParser**: Command-line argument parsing
- **RestSharp**: HTTP client for API submission
- **Microsoft.Extensions.Configuration**: Configuration management

## Example Output

```json
{
  "attestation": {
    "content": {
      "orgId": "11111111-1111-1111-1111-111111111111",
      "tenantId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      "eventId": "550e8400-e29b-41d4-a716-446655440000",
      "documentId": "doc-001",
      "documentRef": "371b3c2889b76b22f6c761ba74534c451f5d7226673eab6e363a11a61e2af6f6",
      "timestamp": "2024-01-15T10:30:45.123Z",
      "version": 1
    },
    "proofs": [
      {
        "id": "abc123...",
        "signature": "3045022100...",
        "algorithm": "SECP256K1_RFC8785_V1"
      }
    ]
  },
  "metadata": {
    "hash": "def456...",
    "tags": {
      "generator": "DotNet-SDK",
      "category": "batch-1"
    }
  }
}
```

## Troubleshooting

### Build Errors

If you encounter build errors, ensure you have .NET 8.0 SDK:

```bash
dotnet --version
```

### NuGet Package Restore Issues

Clear the NuGet cache and restore:

```bash
dotnet nuget locals all --clear
dotnet restore
```

### Platform-Specific Issues

For Linux/macOS users, ensure the scripts are executable:

```bash
chmod +x setup.sh run.sh
```

### API Key Issues

Make sure your API key is properly configured in `config/config.json` or passed via the `--api-key` flag.

## Support

This SDK supports:
- **Windows**: 10, 11, Server 2016+
- **Linux**: Ubuntu, Debian, CentOS, RHEL, Alpine
- **macOS**: 10.14+ (Intel and Apple Silicon)

## License

This SDK is part of the DED project and follows the same licensing terms.