use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::env;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub api_key: String,
    pub api_endpoint: String,
    pub org_id: String,
    pub tenant_id: String,
    pub output_dir: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub private_key: Option<String>,
}

impl Default for Config {
    fn default() -> Self {
        Config {
            api_key: "YOUR_API_KEY_HERE".to_string(),
            api_endpoint: "https://de-api.constellationnetwork.io/v1/fingerprints".to_string(),
            org_id: "11111111-1111-1111-1111-111111111111".to_string(),
            tenant_id: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa".to_string(),
            output_dir: "./output".to_string(),
            private_key: None,
        }
    }
}

impl Config {
    /// Apply environment variable overrides
    pub fn with_env_overrides(mut self) -> Self {
        if let Ok(val) = env::var("DED_API_KEY") {
            self.api_key = val;
        }
        if let Ok(val) = env::var("DED_API_ENDPOINT") {
            self.api_endpoint = val;
        }
        if let Ok(val) = env::var("DED_ORG_ID") {
            self.org_id = val;
        }
        if let Ok(val) = env::var("DED_TENANT_ID") {
            self.tenant_id = val;
        }
        if let Ok(val) = env::var("DED_OUTPUT_DIR") {
            self.output_dir = val;
        }
        if let Ok(val) = env::var("DED_PRIVATE_KEY") {
            self.private_key = Some(val);
        }
        self
    }

    /// Check if the API key is configured
    pub fn is_api_key_configured(&self) -> bool {
        !self.api_key.is_empty() && self.api_key != "YOUR_API_KEY_HERE"
    }

    /// Display configuration info
    pub fn display_info(&self) {
        println!("\n📋 Current Configuration:");
        println!("────────────────────────────────────");

        if self.is_api_key_configured() {
            println!("  API Key: {}...", &self.api_key[..10.min(self.api_key.len())]);
        } else {
            println!("  API Key: Not configured");
        }

        println!("  API Endpoint: {}", self.api_endpoint);
        println!("  Organization ID: {}", self.org_id);
        println!("  Tenant ID: {}", self.tenant_id);
        println!("  Output Directory: {}", self.output_dir);

        if self.private_key.is_some() {
            println!("  Private Key: Configured");
        } else {
            println!("  Private Key: Will be generated");
        }

        println!("\n  Environment Variable Overrides:");
        println!("  • DED_API_KEY");
        println!("  • DED_API_ENDPOINT");
        println!("  • DED_ORG_ID");
        println!("  • DED_TENANT_ID");
        println!("  • DED_OUTPUT_DIR");
        println!("  • DED_PRIVATE_KEY");
        println!("\n  Priority: Environment Variables > config.toml > Defaults");
    }
}

pub fn load_config(path: &Path) -> Result<Config> {
    let mut config = if path.exists() {
        let content = fs::read_to_string(path)?;
        toml::from_str(&content)?
    } else {
        // Create default config if it doesn't exist
        let default_config = Config::default();

        // Ensure parent directory exists
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }

        // Write default config
        let content = toml::to_string_pretty(&default_config)?;
        fs::write(path, content)?;

        println!("Created default configuration at: {}", path.display());
        default_config
    };

    // Apply environment variable overrides
    config = config.with_env_overrides();

    Ok(config)
}