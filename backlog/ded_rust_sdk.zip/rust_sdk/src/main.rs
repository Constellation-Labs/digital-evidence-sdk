mod fingerprint;
mod config;

use anyhow::Result;
use clap::{Parser, Subcommand};
use fingerprint::Generator;
use std::fs;
use std::path::PathBuf;

#[derive(Parser)]
#[clap(name = "ded-fingerprint")]
#[clap(about = "DED Rust SDK - Generate and submit fingerprints", long_about = None)]
struct Cli {
    /// Configuration file path
    #[clap(short, long, value_name = "FILE", default_value = "config/config.toml")]
    config: PathBuf,

    #[clap(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Generate signed fingerprints
    Generate {
        /// Number of fingerprints to generate
        #[clap(short, long, default_value = "5")]
        count: usize,

        /// Output file path
        #[clap(short, long, default_value = "output/fingerprint_submissions.json")]
        output: PathBuf,

        /// Organization ID override
        #[clap(long)]
        org_id: Option<String>,

        /// Tenant ID override
        #[clap(long)]
        tenant_id: Option<String>,

        /// Private key in hex format
        #[clap(long)]
        private_key: Option<String>,

        /// Generate without metadata
        #[clap(long)]
        no_metadata: bool,

        /// Verbose output
        #[clap(short, long)]
        verbose: bool,
    },

    /// Submit fingerprints to the API
    Submit {
        /// Input file path
        #[clap(short, long, default_value = "output/fingerprint_submissions.json")]
        input: PathBuf,

        /// API key
        #[clap(short = 'k', long)]
        api_key: Option<String>,

        /// API endpoint
        #[clap(short = 'e', long)]
        endpoint: Option<String>,

        /// Organization ID override
        #[clap(long)]
        org_id: Option<String>,

        /// Tenant ID override
        #[clap(long)]
        tenant_id: Option<String>,
    },

    /// Display current configuration
    Config,

    /// Display key information
    Info,
}

fn generate_fingerprints(
    config: &config::Config,
    count: usize,
    output: PathBuf,
    org_id: Option<String>,
    tenant_id: Option<String>,
    private_key: Option<String>,
    no_metadata: bool,
    verbose: bool,
) -> Result<()> {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║     Generating Signed Fingerprints                          ║");
    println!("╚══════════════════════════════════════════════════════════════╝");
    println!();
    println!("Configuration:");
    println!("  • Count: {} fingerprints", count);
    println!("  • Output: {}", output.display());
    println!("  • Metadata: {}", !no_metadata);
    println!();

    // Use overrides or fall back to config
    let org_id = org_id.unwrap_or_else(|| config.org_id.clone());
    let tenant_id = tenant_id.unwrap_or_else(|| config.tenant_id.clone());
    let private_key = private_key.or_else(|| config.private_key.clone());

    // Create generator
    let generator = Generator::new(
        Some(org_id.clone()),
        Some(tenant_id.clone()),
        private_key,
    )?;

    // Generate fingerprints
    let submissions = generator.generate_batch(count, !no_metadata)?;

    // Ensure output directory exists
    if let Some(parent) = output.parent() {
        fs::create_dir_all(parent)?;
    }

    // Write to file
    let json = serde_json::to_string_pretty(&submissions)?;
    fs::write(&output, json)?;

    let key_info = generator.get_key_info();
    let pub_key = &key_info["publicKey"];
    let truncated_key = if pub_key.len() > 32 {
        format!("{}...", &pub_key[..32])
    } else {
        pub_key.to_string()
    };

    println!("✅ Generated {} signed fingerprints", count);
    println!("📁 Output saved to: {}", output.display());
    println!("🔑 Public Key: {}", truncated_key);
    println!("🏢 Organization: {}", org_id);
    println!("👥 Tenant: {}", tenant_id);

    if verbose {
        println!("\n📝 Submission Details:");
        for (i, sub) in submissions.iter().enumerate() {
            println!("\n  {}. Event ID: {}", i + 1, sub.attestation.content.event_id);
            println!("     Document: {}", sub.attestation.content.document_id);
            println!("     Version: {}", sub.attestation.content.version);
            if let Some(metadata) = &sub.metadata {
                if !metadata.tags.is_empty() {
                    print!("     Tags: ");
                    let tags: Vec<String> = metadata.tags
                        .iter()
                        .map(|(k, v)| format!("{}={}", k, v))
                        .collect();
                    println!("{}", tags.join(", "));
                }
            }
        }
    }

    Ok(())
}

fn submit_fingerprints(
    config: &config::Config,
    input: PathBuf,
    api_key: Option<String>,
    endpoint: Option<String>,
) -> Result<()> {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║     Submitting Fingerprints to API                          ║");
    println!("╚══════════════════════════════════════════════════════════════╝");
    println!();

    let api_key = api_key.unwrap_or_else(|| config.api_key.clone());
    let endpoint = endpoint.unwrap_or_else(|| config.api_endpoint.clone());

    // Check for API key
    if api_key.is_empty() || api_key == "YOUR_API_KEY_HERE" {
        anyhow::bail!("API key not configured. Please set it in config.toml or use --api-key flag");
    }

    // Check input file exists
    if !input.exists() {
        anyhow::bail!("{} not found. Please run 'generate' command first", input.display());
    }

    println!("Configuration:");
    println!("  • API Endpoint: {}", endpoint);
    println!("  • API Key: {}...", &api_key[..api_key.len().min(10)]);
    println!("  • Input File: {}", input.display());
    println!();
    println!("Submitting...");

    // Read input file
    let data = fs::read_to_string(&input)?;

    // Send request
    let client = reqwest::blocking::Client::new();
    let response = client
        .post(&endpoint)
        .header("Content-Type", "application/json")
        .header("x-api-key", &api_key)
        .body(data)
        .send()?;

    let status = response.status();
    let body = response.text()?;

    println!();
    if status.is_success() {
        println!("✅ Submission successful! (HTTP {})", status.as_u16());
    } else {
        println!("❌ Submission failed (HTTP {})", status.as_u16());
    }

    println!("Response:");
    // Try to pretty print JSON response
    if let Ok(json_value) = serde_json::from_str::<serde_json::Value>(&body) {
        println!("{}", serde_json::to_string_pretty(&json_value)?);
    } else {
        println!("{}", body);
    }

    Ok(())
}

fn display_info(config: &config::Config) -> Result<()> {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║     DED Rust SDK Information                                ║");
    println!("╚══════════════════════════════════════════════════════════════╝");
    println!();

    let generator = Generator::new(
        Some(config.org_id.clone()),
        Some(config.tenant_id.clone()),
        None,
    )?;

    let key_info = generator.get_key_info();

    println!("Configuration:");
    println!("  • Organization ID: {}", key_info["orgId"]);
    println!("  • Tenant ID: {}", key_info["tenantId"]);
    println!("  • API Endpoint: {}", config.api_endpoint);
    println!();
    println!("Generated Key Info:");
    println!("  • Public Key Length: {} characters", key_info["publicKeyLength"]);
    println!("  • Algorithm: SECP256K1_RFC8785_V1");

    Ok(())
}

fn main() -> Result<()> {
    let cli = Cli::parse();

    // Load configuration
    let config = config::load_config(&cli.config)?;

    match &cli.command {
        Commands::Generate { count, output, org_id, tenant_id, private_key, no_metadata, verbose } => {
            generate_fingerprints(&config, *count, output.clone(), org_id.clone(), tenant_id.clone(), private_key.clone(), *no_metadata, *verbose)?;
        }
        Commands::Submit { input, api_key, endpoint, org_id: _, tenant_id: _ } => {
            submit_fingerprints(&config, input.clone(), api_key.clone(), endpoint.clone())?;
        }
        Commands::Config => {
            config.display_info();
        }
        Commands::Info => {
            display_info(&config)?;
        }
    }

    Ok(())
}