use anyhow::Result;
use chrono::{Utc, Duration};
use serde::{Deserialize, Serialize};
use serde_json_canonicalizer::to_vec;
use secp256k1::{Message, PublicKey, Secp256k1, SecretKey};
use secp256k1::rand::rngs::OsRng;
use sha2::{Digest, Sha256, Sha512};
use uuid::Uuid;
use std::collections::HashMap;

/// Core fingerprint data structure
#[derive(Serialize, Deserialize, Debug, Clone)]
#[serde(rename_all = "camelCase")]
pub struct FingerprintValue {
    pub org_id: String,
    pub tenant_id: String,
    pub event_id: String,
    pub document_id: String,
    pub document_ref: String,
    pub timestamp: String,
    pub version: i32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub signer_id: Option<String>,
}

/// Cryptographic signature proof
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SignatureProof {
    pub id: String,
    pub signature: String,
    pub algorithm: String,
}

/// Signed fingerprint with proofs
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct SignedFingerprint {
    pub content: FingerprintValue,
    pub proofs: Vec<SignatureProof>,
}

/// Optional fingerprint metadata
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct FingerprintMetadata {
    pub hash: String,
    pub tags: HashMap<String, String>,
}

/// Complete fingerprint submission
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct FingerprintSubmission {
    pub attestation: SignedFingerprint,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<FingerprintMetadata>,
}

/// Fingerprint generator
pub struct Generator {
    org_id: String,
    tenant_id: String,
    secret_key: SecretKey,
    public_key_hex: String,
}

impl Generator {
    /// Create a new fingerprint generator
    pub fn new(org_id: Option<String>, tenant_id: Option<String>, private_key_hex: Option<String>) -> Result<Self> {
        let org_id = org_id.unwrap_or_else(|| "11111111-1111-1111-1111-111111111111".to_string());
        let tenant_id = tenant_id.unwrap_or_else(|| "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa".to_string());

        let secp = Secp256k1::new();
        let (secret_key, public_key) = if let Some(hex) = private_key_hex {
            // Parse provided private key
            let key_bytes = hex::decode(hex)?;
            let secret_key = SecretKey::from_slice(&key_bytes)?;
            let public_key = PublicKey::from_secret_key(&secp, &secret_key);
            (secret_key, public_key)
        } else {
            // Generate new key pair
            secp.generate_keypair(&mut OsRng)
        };

        // Get public key in uncompressed format without 0x04 prefix
        let public_key_bytes = public_key.serialize_uncompressed();
        let public_key_hex = hex::encode(&public_key_bytes[1..]); // Skip 0x04 prefix

        Ok(Generator {
            org_id,
            tenant_id,
            secret_key,
            public_key_hex,
        })
    }

    /// Compute SHA-256 hash of canonicalized JSON
    fn compute_hash(&self, value: &FingerprintValue) -> Result<String> {
        let canonical = to_vec(value)?;
        let mut hasher = Sha256::new();
        hasher.update(&canonical);
        let hash = hasher.finalize();
        Ok(hex::encode(hash))
    }

    /// Sign fingerprint following the DED protocol
    fn sign_fingerprint(&self, value: &FingerprintValue) -> Result<SignedFingerprint> {
        // Step 1: Canonicalize JSON (RFC 8785)
        let canonical = to_vec(value)?;

        // Step 2: Compute SHA-256 hash
        let mut hasher = Sha256::new();
        hasher.update(&canonical);
        let sha256_hash = hasher.finalize();

        // Step 3: Convert hash to hex string
        let hash_hex = hex::encode(&sha256_hash);

        // Step 4: Treat hex string as UTF-8 bytes
        let hash_bytes_for_signing = hash_hex.as_bytes();

        // Step 5: SHA-512 hash of the hex bytes
        let mut hasher = Sha512::new();
        hasher.update(hash_bytes_for_signing);
        let sha512_hash = hasher.finalize();
        let truncated_hash = &sha512_hash[..32]; // Truncate for secp256k1

        // Step 6: Sign with ECDSA and get DER format
        let secp = Secp256k1::new();
        let message = Message::from_digest_slice(truncated_hash)?;
        let signature = secp.sign_ecdsa(&message, &self.secret_key);

        // Get DER-encoded signature (this is what the API expects)
        let signature_bytes = signature.serialize_der();
        let signature_hex = hex::encode(signature_bytes);

        Ok(SignedFingerprint {
            content: value.clone(),
            proofs: vec![SignatureProof {
                id: self.public_key_hex.clone(),
                signature: signature_hex,
                algorithm: "SECP256K1_RFC8785_V1".to_string(),
            }],
        })
    }

    /// Generate a fingerprint submission
    pub fn generate_submission(&self, index: usize, include_metadata: bool) -> Result<FingerprintSubmission> {
        // Generate IDs
        let event_id = Uuid::new_v4().to_string();
        let document_id = format!("doc-{:03}", index + 1);

        // Generate document reference (hash of document ID)
        let mut hasher = Sha256::new();
        hasher.update(document_id.as_bytes());
        let doc_hash = hasher.finalize();
        let document_ref = hex::encode(doc_hash);

        // Generate timestamp - 5 minutes in the past minus index * 60 seconds
        let timestamp = Utc::now() - Duration::minutes(5) - Duration::minutes(index as i64);
        // Format with millisecond precision
        let timestamp_str = timestamp.format("%Y-%m-%dT%H:%M:%S%.3fZ").to_string();

        let value = FingerprintValue {
            org_id: self.org_id.clone(),
            tenant_id: self.tenant_id.clone(),
            event_id,
            document_id: document_id.clone(),
            document_ref,
            timestamp: timestamp_str,
            version: 1,
            signer_id: None,
        };

        // Sign the fingerprint
        let signed = self.sign_fingerprint(&value)?;

        let mut submission = FingerprintSubmission {
            attestation: signed,
            metadata: None,
        };

        // Add metadata if requested
        if include_metadata {
            let hash = self.compute_hash(&value)?;

            let mut tags = HashMap::new();
            tags.insert("generator".to_string(), "Rust-SDK".to_string());

            if index % 2 == 0 {
                tags.insert("index".to_string(), index.to_string());
                tags.insert("category".to_string(), "batch-1".to_string());
                if index % 3 == 0 {
                    tags.insert("priority".to_string(), "high".to_string());
                }
            }

            submission.metadata = Some(FingerprintMetadata { hash, tags });
        }

        Ok(submission)
    }

    /// Generate a batch of fingerprint submissions
    pub fn generate_batch(&self, count: usize, include_metadata: bool) -> Result<Vec<FingerprintSubmission>> {
        let mut submissions = Vec::new();
        for i in 0..count {
            submissions.push(self.generate_submission(i, include_metadata)?);
        }
        Ok(submissions)
    }

    /// Get key information
    pub fn get_key_info(&self) -> HashMap<String, String> {
        let mut info = HashMap::new();
        info.insert("publicKey".to_string(), self.public_key_hex.clone());
        info.insert("publicKeyLength".to_string(), self.public_key_hex.len().to_string());
        info.insert("orgId".to_string(), self.org_id.clone());
        info.insert("tenantId".to_string(), self.tenant_id.clone());
        info
    }
}