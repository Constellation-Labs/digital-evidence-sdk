#!/bin/bash

# DED Rust SDK Setup Script

set -e  # Exit on error

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║     DED Rust SDK Setup                                      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check for Rust installation
check_rust() {
    if command -v rustc &> /dev/null; then
        echo "✅ Rust is installed: $(rustc --version)"
        return 0
    else
        echo "❌ Rust is not installed"
        return 1
    fi
}

# Install Rust
install_rust() {
    echo "Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
    echo "✅ Rust installed successfully"
}

# Main setup
main() {
    echo "Checking prerequisites..."
    echo ""

    # Check Rust
    if ! check_rust; then
        read -p "Would you like to install Rust? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_rust
        else
            echo "⚠️  Rust is required to build the SDK"
            exit 1
        fi
    fi

    echo ""
    echo "Building the SDK..."
    cargo build --release

    if [ $? -eq 0 ]; then
        echo ""
        echo "✅ Build successful!"
        echo ""
        echo "Binary location: target/release/ded-fingerprint"
        echo ""
        echo "Configuration Setup:"
        echo "──────────────────────────────────────"
        echo "1. Edit config/config.toml"
        echo "2. Replace 'YOUR_API_KEY_HERE' with your actual API key"
        echo ""
        echo "Usage Examples:"
        echo "──────────────────────────────────────"
        echo "• Generate fingerprints:"
        echo "  cargo run -- generate --count 5"
        echo ""
        echo "• Submit to API:"
        echo "  cargo run -- submit --input output/fingerprint_submissions.json"
        echo ""
        echo "• Display info:"
        echo "  cargo run -- info"
        echo ""
        echo "Or use the compiled binary directly:"
        echo "  ./target/release/ded-fingerprint generate --count 5"
        echo ""
    else
        echo ""
        echo "❌ Build failed. Please check the errors above."
        exit 1
    fi
}

main "$@"