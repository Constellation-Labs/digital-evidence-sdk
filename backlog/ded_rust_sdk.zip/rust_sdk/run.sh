#!/bin/bash

# DED Rust SDK Runner Script

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
CONFIG_FILE="config/config.toml"
OUTPUT_DIR="output"
BINARY="./target/release/ded-fingerprint"

# Display header
display_header() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║     DED Rust SDK Runner                                     ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Check binary exists
check_binary() {
    if [ ! -f "$BINARY" ]; then
        echo -e "${YELLOW}Binary not found. Building...${NC}"
        cargo build --release
        if [ $? -ne 0 ]; then
            echo -e "${RED}Build failed!${NC}"
            exit 1
        fi
    fi
}

# Load API key from config
load_api_key() {
    if [ -f "$CONFIG_FILE" ]; then
        API_KEY=$(grep "api_key" "$CONFIG_FILE" | cut -d '"' -f 2)
        if [ "$API_KEY" == "YOUR_API_KEY_HERE" ] || [ -z "$API_KEY" ]; then
            return 1
        fi
        return 0
    fi
    return 1
}

# Display menu
display_menu() {
    echo "Select an operation:"
    echo "──────────────────────────────────────"
    echo "1) Generate fingerprints"
    echo "2) Submit fingerprints to API"
    echo "3) Generate and submit (full flow)"
    echo "4) Show current configuration"
    echo "5) Configure SDK (API key, Org ID, Tenant ID)"
    echo "6) Display SDK info"
    echo "7) Exit"
    echo ""
    read -p "Enter your choice [1-7]: " choice
}

# Generate fingerprints
generate_fingerprints() {
    echo ""
    read -p "How many fingerprints to generate? [default: 5]: " count
    count=${count:-5}

    read -p "Include metadata? (y/n) [default: y]: " include_metadata
    if [[ "$include_metadata" =~ ^[Nn]$ ]]; then
        metadata_flag="--no-metadata"
    else
        metadata_flag=""
    fi

    read -p "Use custom Org ID? (leave empty for configured): " custom_org
    read -p "Use custom Tenant ID? (leave empty for configured): " custom_tenant
    read -p "Use custom private key? (leave empty to generate): " custom_key

    org_flag=""
    tenant_flag=""
    key_flag=""

    if [ -n "$custom_org" ]; then
        org_flag="--org-id $custom_org"
    fi
    if [ -n "$custom_tenant" ]; then
        tenant_flag="--tenant-id $custom_tenant"
    fi
    if [ -n "$custom_key" ]; then
        key_flag="--private-key $custom_key"
    fi

    echo -e "\n${GREEN}Generating $count fingerprints...${NC}"
    $BINARY generate --count "$count" $metadata_flag $org_flag $tenant_flag $key_flag --verbose

    echo -e "\n${GREEN}✅ Generation complete!${NC}"
}

# Submit fingerprints
submit_fingerprints() {
    if ! load_api_key; then
        echo -e "${RED}API key not configured!${NC}"
        echo "Please configure your API key first (option 5)"
        return 1
    fi

    local input_file="$OUTPUT_DIR/fingerprint_submissions.json"

    if [ ! -f "$input_file" ]; then
        echo -e "${YELLOW}No fingerprints found to submit.${NC}"
        echo "Please generate fingerprints first (option 1)"
        return 1
    fi

    echo -e "\n${GREEN}Submitting fingerprints...${NC}"
    $BINARY submit

    echo -e "\n${GREEN}✅ Submission complete!${NC}"
}

# Show current configuration
show_configuration() {
    echo ""
    echo -e "${BLUE}Current Configuration:${NC}"
    echo "──────────────────────────────────────"
    $BINARY config
}

# Configure SDK
configure_sdk() {
    echo ""
    echo -e "${BLUE}SDK Configuration${NC}"
    echo "Current configuration file: $CONFIG_FILE"
    echo ""

    # Load current values
    if [ -f "$CONFIG_FILE" ]; then
        CURRENT_API_KEY=$(grep "api_key" "$CONFIG_FILE" | cut -d '"' -f 2)
        CURRENT_ORG_ID=$(grep "org_id" "$CONFIG_FILE" | cut -d '"' -f 2)
        CURRENT_TENANT_ID=$(grep "tenant_id" "$CONFIG_FILE" | cut -d '"' -f 2)
        CURRENT_ENDPOINT=$(grep "api_endpoint" "$CONFIG_FILE" | cut -d '"' -f 2)
    else
        CURRENT_API_KEY="YOUR_API_KEY_HERE"
        CURRENT_ORG_ID="11111111-1111-1111-1111-111111111111"
        CURRENT_TENANT_ID="aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
        CURRENT_ENDPOINT="https://de-api.constellationnetwork.io/v1/fingerprints"
    fi

    # Display current values
    echo "Current values:"
    if [ "$CURRENT_API_KEY" != "YOUR_API_KEY_HERE" ] && [ -n "$CURRENT_API_KEY" ]; then
        echo -e "  API Key: ${YELLOW}${CURRENT_API_KEY:0:10}...${NC}"
    else
        echo -e "  API Key: ${YELLOW}Not configured${NC}"
    fi
    echo -e "  Org ID: ${YELLOW}$CURRENT_ORG_ID${NC}"
    echo -e "  Tenant ID: ${YELLOW}$CURRENT_TENANT_ID${NC}"
    echo ""

    # Get new values
    read -p "Enter API key (or press Enter to keep current): " new_key
    read -p "Enter Organization ID (or press Enter to keep current): " new_org
    read -p "Enter Tenant ID (or press Enter to keep current): " new_tenant
    read -p "Enter API Endpoint (or press Enter to keep default): " new_endpoint
    read -p "Enter Private Key in hex (or press Enter to auto-generate): " new_private_key

    # Use existing values if not provided
    new_key=${new_key:-$CURRENT_API_KEY}
    new_org=${new_org:-$CURRENT_ORG_ID}
    new_tenant=${new_tenant:-$CURRENT_TENANT_ID}
    new_endpoint=${new_endpoint:-$CURRENT_ENDPOINT}

    # Create config directory if it doesn't exist
    mkdir -p config

    # Update config file
    cat > "$CONFIG_FILE" <<EOF
# DED Rust SDK Configuration

# API Configuration
api_key = "$new_key"
api_endpoint = "$new_endpoint"

# Organization Configuration
org_id = "$new_org"
tenant_id = "$new_tenant"

# Output Configuration
output_dir = "./output"
EOF

    if [ -n "$new_private_key" ]; then
        echo "" >> "$CONFIG_FILE"
        echo "# Optional: Private key for signing (hex format)" >> "$CONFIG_FILE"
        echo "private_key = \"$new_private_key\"" >> "$CONFIG_FILE"
    fi

    echo -e "\n${GREEN}✅ Configuration updated successfully${NC}"
    echo ""
    echo "You can also use environment variables:"
    echo "  export DED_API_KEY='your_api_key'"
    echo "  export DED_ORG_ID='your_org_id'"
    echo "  export DED_TENANT_ID='your_tenant_id'"
}

# Display SDK info
display_sdk_info() {
    echo ""
    $BINARY info
}

# Full flow
full_flow() {
    echo -e "\n${BLUE}Running full flow: Generate and Submit${NC}\n"

    # Generate
    read -p "How many fingerprints to generate? [default: 5]: " count
    count=${count:-5}

    echo -e "\n${GREEN}Step 1: Generating $count fingerprints...${NC}"
    $BINARY generate --count "$count" --verbose

    # Submit
    if load_api_key; then
        echo -e "\n${GREEN}Step 2: Submitting to API...${NC}"
        submit_fingerprints
        echo -e "\n${GREEN}✅ Full flow complete!${NC}"
    else
        echo -e "\n${YELLOW}⚠️  API key not configured. Skipping submission.${NC}"
        echo "Run option 5 to configure API key, then option 2 to submit."
    fi
}

# Check prerequisites
check_prerequisites() {
    # Check for Rust
    if ! command -v cargo &> /dev/null; then
        echo -e "${RED}Rust/Cargo is not installed!${NC}"
        echo "Please install Rust from https://rustup.rs"
        exit 1
    fi
}

# Main function
main() {
    display_header
    check_prerequisites
    check_binary

    while true; do
        display_menu

        case $choice in
            1)
                generate_fingerprints
                ;;
            2)
                submit_fingerprints
                ;;
            3)
                full_flow
                ;;
            4)
                show_configuration
                ;;
            5)
                configure_sdk
                ;;
            6)
                display_sdk_info
                ;;
            7)
                echo -e "\n${GREEN}Goodbye!${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}Invalid option. Please try again.${NC}"
                ;;
        esac

        echo ""
        read -p "Press Enter to continue..."
        echo ""
    done
}

# Run main function
main "$@"