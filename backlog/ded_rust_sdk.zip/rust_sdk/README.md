# DED Rust SDK

Rust SDK for generating and submitting cryptographically signed fingerprints to the DED (Digital Evidence) Metagraph.

## Features

- ✨ Generate SECP256K1 signed fingerprints with RFC 8785 JSON canonicalization
- 🔐 DER-encoded ECDSA signatures compatible with the DED API
- 📦 Batch generation with optional metadata
- 🚀 Simple CLI interface for generation and submission
- 🔧 Configurable via TOML file

## Installation

### Prerequisites

- Rust 1.70 or later
- Cargo (comes with Rust)

### Quick Setup

```bash
# Run the setup script
chmod +x setup.sh
./setup.sh

# Or manually build
cargo build --release
```

## Configuration

Edit `config/config.toml` to set your API key and customize settings:

```toml
# API Configuration
api_key = "YOUR_API_KEY_HERE"
api_endpoint = "https://de-api.constellationnetwork.io/v1/fingerprints"

# Organization Configuration
org_id = "11111111-1111-1111-1111-111111111111"
tenant_id = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"

# Output Configuration
output_dir = "./output"
```

## Usage

### Using the Interactive Runner

```bash
chmod +x run.sh
./run.sh
```

The runner provides a menu-driven interface for:
- Generating fingerprints
- Submitting to the API
- Running the full flow (generate + submit)
- Configuring your API key

### Direct CLI Usage

#### Generate Fingerprints

```bash
# Generate 5 fingerprints with metadata (default)
cargo run -- generate

# Generate 10 fingerprints without metadata
cargo run -- generate --count 10 --no-metadata

# Generate with verbose output
cargo run -- generate --verbose

# Using the compiled binary
./target/release/ded-fingerprint generate --count 5
```

#### Submit to API

```bash
# Submit using config file settings
cargo run -- submit

# Submit with custom API key
cargo run -- submit --api-key "your_api_key_here"

# Submit from specific file
cargo run -- submit --input output/fingerprint_submissions.json
```

#### Display SDK Info

```bash
cargo run -- info
```

## Project Structure

```
rust_sdk/
├── Cargo.toml          # Project dependencies
├── config/
│   └── config.toml     # Configuration file
├── output/             # Generated fingerprint files
├── src/
│   ├── main.rs         # CLI entry point
│   ├── fingerprint.rs  # Fingerprint generation logic
│   └── config.rs       # Configuration handling
├── setup.sh            # Setup script
├── run.sh              # Interactive runner script
└── README.md           # This file
```

## Technical Details

### Signing Algorithm

The SDK implements the SECP256K1_RFC8785_V1 signature algorithm:

1. **Canonicalization**: JSON is canonicalized according to RFC 8785
2. **Hashing**: SHA-256 hash of the canonical JSON
3. **Double-Hash Protocol**:
   - Convert SHA-256 hash to hex string
   - Treat hex string as UTF-8 bytes
   - Apply SHA-512 and truncate to 32 bytes
4. **Signing**: ECDSA signature with secp256k1, output in DER format

### Dependencies

- `secp256k1`: ECDSA cryptographic operations
- `serde_json_canonicalizer`: RFC 8785 JSON canonicalization
- `sha2`: SHA-256 and SHA-512 hashing
- `chrono`: Timestamp generation
- `uuid`: UUID v4 generation
- `clap`: Command-line argument parsing
- `reqwest`: HTTP client for API submission

## Example Output

```json
{
  "attestation": {
    "content": {
      "orgId": "11111111-1111-1111-1111-111111111111",
      "tenantId": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
      "eventId": "550e8400-e29b-41d4-a716-446655440000",
      "documentId": "doc-001",
      "documentRef": "371b3c2889b76b22f6c761ba74534c451f5d7226673eab6e363a11a61e2af6f6",
      "timestamp": "2024-01-15T10:30:45.123Z",
      "version": 1
    },
    "proofs": [
      {
        "id": "abc123...",
        "signature": "3045022100...",
        "algorithm": "SECP256K1_RFC8785_V1"
      }
    ]
  },
  "metadata": {
    "hash": "def456...",
    "tags": {
      "generator": "Rust-SDK",
      "category": "batch-1"
    }
  }
}
```

## Troubleshooting

### Build Errors

If you encounter build errors, ensure you have the latest Rust version:

```bash
rustup update
```

### API Key Issues

Make sure your API key is properly configured in `config/config.toml` or passed via the `--api-key` flag.

### Signature Validation

The SDK generates DER-encoded ECDSA signatures that are compatible with the DED API. If you encounter validation errors, ensure you're using the latest version of the SDK.

## License

This SDK is part of the DED project and follows the same licensing terms.